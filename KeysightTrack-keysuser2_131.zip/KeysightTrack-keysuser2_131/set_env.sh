#!/usr/bin/env bash

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/cuda/lib64
export CUDA_PATH=/usr/local/cuda
export PKG_CONFIG_SYSROOT_DIR=/usr/local/include

# For meson to pick up the dependency, the BOOST_ROOT, BOOST_INCLUDEDIR and BOOST_LIBRARYDIR
# environment variables are needed. Those are set if not previously set

if [ -n "$(command -v yum)" ]; then
    if [ -z $BOOST_ROOT ]; then
        export BOOST_ROOT=/usr
    fi
    if [ -z $BOOST_INCLUDEDIR ]; then
        export BOOST_INCLUDEDIR=/usr/local/include/boost
    fi
    if [ -z $BOOST_LIBRARYDIR ]; then
        export BOOST_LIBRARYDIR=/usr/lib64
    fi
fi

export ROOT_DIR=$(git rev-parse --show-toplevel)
echo "Root directory: $ROOT_DIR"

# Add current directory to make the meson wrapper substitute the actual meson script
export PATH=$ROOT_DIR/scripts:/usr/local/cuda/bin:$PKG_CONFIG_SYSROOT_DIR:$PATH:

# Finally remove all duplicates from the PATH variable
# (which can happen if this script is sourced or executed multiple times)
export PATH=$(printf %s "$PATH" | awk -vRS=: '!a[$0]++' | paste --serial --delimiters=:)
