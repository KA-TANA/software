# Keysight Track Repository

## Preparation of the repository

The first time you clone the repository, it is recommended to check that all required Python packages have been installed. In order to do that, go to the *repository root directory* and run:

```sh
pip3 install -r requirements.txt
```

## Development Environment Setup

In each terminal instance, before trying to build or run the code, some environment variables need to be set. Go to the *repository root directory* and run:

```sh
source set_env.sh
```

This **needs to be done in each terminal instance** you plan to use.

> **Note:** If you are using the VSCode tasks described in the [VSCode tasks](#vscode-tasks) section, this is done for you automatically.

## Building and Running the Code

Before building and running the code, be sure to have properly setted up the environment as described in the [Development Environment Setup](#development-environment-setup) section.

To build the code you need first to **create the build directory**. This is done in the repository root directory with:

```sh
meson setup build -Dtarget=<target>
```

Where `<target>` identifies the binary you want to compile, between:

- `tutorial` - For the tutorial code under `src/tutorial`.
- `modem_rx` - For the modem code under `src/modem_rx`. This is the **default value**.

> **Note**: If no `<target>` is provided, `modem_rx` is used by default.

The directory only needs to be created **once**. The same directory can be reused for multiple builds.

The next step is to **build the code** which is achieved by:

```sh
meson compile -C build
```

The last step is to **test the code** which is achieved by:

```sh
meson test -C build
```

> **Note:** Alternatively, you can use VSCode tasks to build and run the code as described in the [VSCode tasks](#vscode-tasks) section.

## Adding Files to the Repository

Add header and source files only in the `inc`, `src` and/or `test` directories of either `src/modem_rx` or `src/tutorial` directories.

If you are adding **headers** (i.e., `.h`, `.hpp`, `.cuh`), there is nothing else you need to do in order to incorporate those files into the build process.

For **object** files (i.e., `.c`, `.cpp`, `.cu`), you will need to add them manually to the build system so that they are compiled. This is done by manually modifying the corresponding `meson.build` file.

- If the file is under `src/tutorial`, you will need to modify the [`src/tutorial/meson.build`](./src/tutorial/meson.build) file.
- If the file is under `src/modem_rx`, you will need to modify the [`src/modem_rx/meson.build`](./src/modem_rx/meson.build) file.

If both cases, the modification you need to do is to add the object file to the `files` list. For example:

```python
prj_src = files(
    'src/cudaScalarProduct1.cu',
    'src/cudaScalarProduct2.cu',
    'src/cudaScalarProduct3.cu',
    'test/main.cpp',
    <your_file_goes_here>,
)
```

## VSCode Environment

### Repository Configuration

The repository is configured for use with VSCode. The following functions are already enabled:

- Code highlighting.
- Code autocompletion.
- Spell checking.
- Code autoformating (each time a file is saved in VSCode, the format is changed to meet the coding guidelines).
- A set of predefined tasks for most common use cases (e.g., building and running the code).

### Extensions Installation

In order to u these functions, you need to:

1. Open a workspace pointing to the repository root directory in VSCode.
2. Install the recommended extensions through VSCode GUI. The list of recommended extensions can also be found in the corresponsing [`extensions.json`](.vscode/extensions.json) file.

### VSCode Tasks

The following tasks are defined to be used through the `Terminal/Run Task...` option in VSCode:

- `<target>: setup` - Configures the build directory for the target `<target>`.
- `<target>: compile` - Builds the build directory for the target `<target>`.
- `<target>: test` - Run the tests for the target `<target>`.
- `all: clean` - Deletes the build directory.

> **Note:** Some additional tasks are also defined to be used with the debugger.
