classdef pn < handle
    % example for g(x) = 1 + x^18 + x^23 => 
    % g = [1 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1];
    %
    properties
        g; % polynomial
        Deg; % degree 
        B; % encoding matrix
        A; % encoding matrix
        C; % encoding matrix
        D; % encoding matrix
        M; % block size for encoding in M by M blocks "per cycle"
        seed;
    end
    
    methods
        %
        %
        %
        function obj = pn(g,M,seed) 
            obj.M = M;
            obj.g = g;
            obj.seed = seed(:);
            
            obj.Deg = numel(g)-1;
            obj.B = eye(1,obj.Deg);
            obj.A = [g(end-1:-1:1); eye(obj.Deg-1, obj.Deg-1) zeros(obj.Deg-1,1)];

            A = obj.A;
            obj.C = obj.B;
            for m=1:M-1
              obj.C =[obj.C ; mod(obj.B*A,2)];
              A = mod(A*obj.A,2);
            end            
            obj.D = A;
        end

        
        %%
        %% PN generation
        %%
        function [y obj] = run(obj)        
            x = obj.seed;

            y = mod(obj.C * x,2);
            x = mod(obj.D * x,2);
            
            obj.seed = x;            
        end
    end 
end


 