classdef cp
    properties
        Nfft;           % cell BW,  DFT size
        Nsym;
        cpSize;
        marginCp;
    end % of properties

    methods
        %
        %
        function obj = cp(Nfft,Nsym, cpSize)
                obj.Nfft = Nfft;
                obj.Nsym = Nsym;
                obj.cpSize = cpSize;
                obj.marginCp = min(obj.cpSize)/2;
        end
        %
        %
        function v = run_tx(obj,u)
            currPos = 1;
            for n=1:obj.Nsym
                nxtPos = currPos + obj.cpSize(n)+obj.Nfft;
                v(currPos : nxtPos - 1, 1) = [u(end-obj.cpSize(n)+1:end, n) ; u(:,n)] ;    
                currPos = nxtPos;
            end            
        end
        %
        %
        function v = run_rx(obj,u, sto)
            u = u(:);
            currPos = 1 - obj.marginCp + sto;
            for n=1:obj.Nsym
                currPos = currPos + obj.cpSize(n);
                v(:, n) = u(currPos : currPos + obj.Nfft - 1);    
                currPos = currPos + obj.Nfft;
            end            
        end
        
        
        %
        %
    end % of methods
end % of class definition


 