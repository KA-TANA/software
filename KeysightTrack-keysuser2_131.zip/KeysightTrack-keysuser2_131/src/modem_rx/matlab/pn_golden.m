classdef pn_golden < handle
    % example for g(x) = 1 + x^18 + x^23 => 
    % g = [1 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1];
    %
    properties
        %g; % polynomial
        %Deg; % degree 
        %B; % encoding matrix
        %A; % encoding matrix
        %C; % encoding matrix
        %D; % encoding matrix
        M; % block size for encoding in M by M blocks "per cycle"
        seed;
	pn1;
	pn2;
    end
    
    methods
        % Class constructor
        % Keeping the same parameters as old PN class
        % to keep plug'n'play compatibility (old code is commented out)
        function obj = pn_golden(g,M,seed) 
            %obj.M = M;
            %obj.g = g;
            %obj.seed = seed(:);
            
            %obj.Deg = numel(g)-1;
            %obj.B = eye(1,obj.Deg);
            %obj.A = [g(end-1:-1:1); eye(obj.Deg-1, obj.Deg-1) zeros(obj.Deg-1,1)];

            %A = obj.A;
            %obj.C = obj.B;
            %for m=1:M-1
            %  obj.C =[obj.C ; mod(obj.B*A,2)];
            %  A = mod(A*obj.A,2);
            %end            
            %obj.D = A;

	    g1 = [1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 1];
	    g2 = [1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1];
	    % both g1 and g2 have the same number of elements (32)
	    obj.seed = eye(numel(g1)-1,1);
            obj.pn1 = pn(g1, M, obj.seed);
            obj.pn2 = pn(g2, M, obj.seed);
        end

        
        %%
        %% PN generation
        %% (old code is commented out)
        function [y obj] = run(obj)        
            %x = obj.seed;

            %y = mod(obj.C * x,2);
            %x = mod(obj.D * x,2);
            
            %obj.seed = x;            
	    [pnt1, obj.pn1] = obj.pn1.run;
            [pnt2, obj.pn2] = obj.pn2.run;

            y = mod(pnt1 + pnt2, 2);
        end
    end 
end


 
