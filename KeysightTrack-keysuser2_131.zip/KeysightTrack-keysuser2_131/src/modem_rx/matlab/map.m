classdef map
    properties
        Nfft;           % cell BW,  DFT size
        FreqMask;        % channel allocation mask in frequency for data
        TimeMask;        % channel allocation mask in slot for data
        Nsym;
    end % of properties

    methods
        %
        %
        function obj = map(FreqMask,TimeMask)
                obj.Nfft = numel(FreqMask);
                obj.FreqMask = FreqMask(:);
                obj.Nsym = numel(TimeMask);
                obj.TimeMask = TimeMask(:);
        end
        %
        %
        function v = run_tx(obj,u)

            v = zeros(obj.Nfft,obj.Nsym);
            curPos = 1;
            for t= 1:obj.Nsym
                if obj.TimeMask(t) == 1,
                    for f=1:obj.Nfft
                        if obj.FreqMask(f) == 1, 
                            v(f,t) = u(curPos);
                            curPos = curPos+1;
                        end
                    end
                end
            end
        end
        
        function v = run_rx(obj,u)

            curPos = 1;
            for t= 1:obj.Nsym
                if obj.TimeMask(t) == 1,
                    for f=1:obj.Nfft
                        if obj.FreqMask(f) == 1, 
                            v(curPos) = u(f,t);
                            curPos = curPos+1;
                        end
                    end
                end
            end
        end
        
        
        %
        %
    end % of methods
end % of class definition


 