classdef int

    properties
        g0;
        g1;
        E0;
        E1;
        Q; 
    end
    
    methods
        %
        %
        %
        function obj = int(G,C,QamSize) 
                obj.Q = log2(QamSize);
                obj.E0 = ceil( (G/obj.Q) / C ) * obj.Q;
                obj.g0 = mod(G/obj.Q, C);
                obj.g1 = C - obj.g0;
                obj.E1 = floor( (G/obj.Q) / C ) * obj.Q;
                
                if G ~= obj.E0*obj.g0 + obj.E1*obj.g1, error('something went wrong computing rate matching parameters '); end                        
        end

        %%
        %% interleaving
        %%
        function v = run_tx(obj,u)

            curPos = 1;
            for g=0:obj.g0-1
                nxtPos = curPos + obj.E0;
                w = u(curPos:nxtPos-1,1);
                w = reshape(w, obj.E0/obj.Q, obj.Q)';                
                v(curPos:nxtPos-1,1) = w(:);
                curPos = nxtPos;
            end
            
            for g=0:obj.g1-1
                nxtPos = curPos + obj.E1;
                w = u(curPos:nxtPos-1,1);
                w = reshape(w, obj.E1/obj.Q, obj.Q)';                                
                v(curPos:nxtPos-1,1) = w(:);
                curPos = nxtPos;
            end
            
        end

        function v = run_rx(obj,u)
            u = u(:);
            curPos = 1;
            for g=0:obj.g0-1
                nxtPos = curPos + obj.E0;
                w = u(curPos:nxtPos-1,1);                
                w = reshape(w, obj.Q, obj.E0/obj.Q)';  
                w = w(:);
                v(curPos:nxtPos-1,1) = w;
                curPos = nxtPos;
            end
            
            for g=0:obj.g1-1
                nxtPos = curPos + obj.E1;
                w = u(curPos:nxtPos-1,1);
                w = reshape(w, obj.Q, obj.E1/obj.Q)';  
                w=w(:);
                v(curPos:nxtPos-1,1) = w;
                curPos = nxtPos;
            end
            
        end
        
    end
end

