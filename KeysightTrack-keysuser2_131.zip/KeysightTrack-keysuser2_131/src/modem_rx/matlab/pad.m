classdef pad

    properties
        c0; % The first c0 CBs use K0 bits + F0 filler/padding bits
        c1; % The last c1 CBs use K1 bits + F1 filler/padding bits
        K0; % K0 first systematic bits of the c0 first CBs are carrying information
        K1; % K1 first systematic bits of the c1 last CBs are carrying information
        F0; % number of zero filler bits in first c0 CBs
        F1; % number of zero filler bits in last c1 CBs
    end
    
    methods
        %
        %
        %
        function obj = pad(C,B,K) 
            F = C*K - B;    % total number of filler bits
            obj.F0 = ceil(F/C);
            obj.c0 = rem(F, C);
            obj.K0 = K-obj.F0;

            obj.F1 = floor(F/C);
            obj.c1 = C - obj.c0;
            obj.K1 = K-obj.F1;

            if K ~= obj.F0 + obj.K0, error('something went wrong computing rate matching parameters, K0+F0 != K'); end
            if K ~= obj.F1 + obj.K1, error('something went wrong computing rate matching parameters, K1+F1 != K'); end
            if B ~= obj.c0*obj.K0 + obj.c1*obj.K1, error('something went wrong computing rate matching parameters, c0*K0+c1*K1 != B'); end                       
        end

        %%
        %% segmentation and padding
        %%
        function v = run_tx(obj,u)

            curPos = 1;
            for c=0:obj.c0-1
               nxtPos = curPos + obj.K0;                
               v(:,c+1) = [ u(curPos:nxtPos-1); zeros(obj.F0,1)];
               curPos = nxtPos;
            end
            
            for c=0:obj.c1-1
               nxtPos = curPos + obj.K1;                
               v(:,c+obj.c0+1) = [ u(curPos:nxtPos-1); zeros(obj.F1,1)];
               curPos = nxtPos;
            end
            
        end

        %%
        %% inverse segmentation and padding
        %%
        function v = run_rx(obj,u)

            v = [];
            for c=0:obj.c0-1
               tmp = u(1:obj.K0,c+1);
               v = [v; tmp(:)];
            end
            
            for c=0:obj.c1-1
               tmp =u(1:obj.K1,c+obj.c0+1);
               v = [v; tmp(:)];
            end

        end
        
    end
end

