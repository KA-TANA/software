classdef pdch
    properties
        Nfft;           % cell BW,  DFT size
        FreqMask;       % channel allocation mask in frequency for data
        TimeMask;       % channel allocation mask in slot for data
        Nsym;
        QamSize;
        %
        crc;
        ldpc;
        pad;
        rm;
        int;
        qam;
        map;
        %
        A;  % number of TrBlk bits to encode not counting cluding the additional 16 of the CRC
        B;  % A + 16
        C;  % Number of C fitting in the slot
        G;  % number of bits fitting the slot        
    end % of properties

    methods
        %
        %
        function obj = pdch(FreqMask,TimeMask,TrBlkSize, QamSize)
                obj.Nfft = numel(FreqMask);
                obj.FreqMask = FreqMask(:);
                obj.Nsym = numel(TimeMask);
                obj.TimeMask = TimeMask(:);
                obj.G = sum(FreqMask) * sum(TimeMask) * log2(QamSize);
                
                %
                % create crc object
                crc16 = [1  0 0 0 1   0 0 0 0   0 0 1 0   0 0 0 1];
                obj.crc = crc(crc16,8); % object for operating blockwise
                % create ldpc object
                obj.ldpc = ldpc;                

                %
                
                
                obj.A = TrBlkSize * 8;
                obj.B = obj.A + 16;
                obj.C = ceil( obj.B /obj.ldpc.K);                
                % create segmentation and padding object
                obj.pad = pad(obj.C, obj.B, obj.ldpc.K);                
                % create RM object
                obj.rm = rm(obj.G,obj.C,obj.ldpc.N, QamSize);
                % create int object
                obj.int = int(obj.G, obj.C,QamSize); 
                %create qam object;
                obj.qam = qam(QamSize);  
                %create map
                obj.map = map(FreqMask,TimeMask);
        end
        %
        %
        function X = run_tx(obj,TrBlk)
            
            disp('pdch_tx t/f generation...');
            
            % convert byte sequence to bit sequence
            for n =1: numel(TrBlk)
                tmp = TrBlk(n);
                for k = 7:-1:0
                    x(k+1,n) = floor( tmp / 2^k );
                    tmp = rem(tmp,2^k);
                end
            end
            u = x(:);

            % add crc16
            disp('pdch_tx t/f adding CRC16...');
            v = run(obj.crc,u);                        
            
            % do segmentation and padding to C CBs of size K bits
            disp('pdch_tx t/f segmentation and padding...');
            w = run_tx(obj.pad,v);
            
            % LDPC encoding
            disp('pdch_tx t/f LDPC encoding...');
            for c=1:obj.C
                z(:,c) = run_tx(obj.ldpc,w(:,c));                
            end
            
            % Rate matching to C blocks of E0 and E1.
            disp('pdch_tx t/f Rate matching...');
            q = run_tx(obj.rm,z);

            % interleaving
            disp('pdch_tx t/f interleaving...');
            s = run_tx(obj.int,q);
            
            % QAM modulation
            disp('pdch_tx t/f QAM modulation...');
            r = run_tx(obj.qam,s);
            
            % t/f mapping
            disp('pdch_tx t/f mapping...');
            X = run_tx(obj.map,r);

            % create empty t/F grid
            disp('pdch_tx t/f done!');
        end
        %
        %
        function [u CrcStatus iterations] = run_rx(obj,r)     
            disp('pdch_rx data demodulation...');
            
            % t/f demapping
            disp('pdch_rx t/f demapping...');
            s = run_rx(obj.map,r);

            disp('pdch_rx t/f QAM demodulation...');
            t = run_rx(obj.qam,s);

            disp('pdch_rx t/f deinterleaving...');
            v = obj.int.run_rx(t);

            disp('pdch_rx t/f inverse rate matching...');
            w = run_rx(obj.rm,v);

            disp('pdch_rx t/f ldpc decoding...');
            iterations = 0;
            for c=1:obj.C
                [d(:,c) it] = run_rx(obj.ldpc,w(:,c)); 
                iterations = iterations + it;
            end
            iterations = floor(iterations/obj.C);

            disp('pdch_rx t/f inverse padding...');
            c = run_rx(obj.pad,d);

            disp('pdch_rx t/f crc check...');
            b = run(obj.crc,c);
            a = b(1:obj.A);
            check = b(end-15:end);
            if sum(check) == 0
                CrcStatus = 0; % CRC OK
            else
                CrcStatus = 1; % CRC error
            end
                        
            % convert bit sequence to byte sequencet
            a = reshape(a,8,obj.A/8)';            
            u = a*2.^([0:7]');
            
        end
        
        %
        %
    end % of methods
end % of class definition 