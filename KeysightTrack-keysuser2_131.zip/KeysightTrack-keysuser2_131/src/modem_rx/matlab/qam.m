classdef qam

    properties
        Q; 
        P;
    end
    
    methods
        %
        %
        %
        function obj = qam(QamSize)
      
            obj.Q = log2(QamSize);
            switch(QamSize)
                case 2
                    for i=0:QamSize-1
                        b = dec2bin(i, obj.Q); 
                        b = double(b(end:-1:1)')-48; 
                        obj.P(i+1) = (1/sqrt(2)) * ...
                                   (... 
                                        ( (1-2*b(1)) ) +...
                                      j*( (1-2*b(1)) )  ...
                                    ); 
                    end
                    
                case 4
                    for i=0:QamSize-1
                        b = dec2bin(i, obj.Q); 
                        b = double(b(end:-1:1)')-48; 
                        obj.P(i+1) = (1/sqrt(2)) * ...
                                   (... 
                                        ( (1-2*b(1)) ) +...
                                      j*( (1-2*b(2)) )  ...
                                    ); 
                    end

                case 16
                    for i=0:QamSize-1
                        b = dec2bin(i, obj.Q); 
                        b = double(b(end:-1:1)')-48; 
                        obj.P(i+1) = (1/sqrt(10)) * ...
                                   (... 
                                        ( (1-2*b(1))*(2-(1-2*b(3))) ) +...
                                      j*( (1-2*b(2))*(2-(1-2*b(4))) )  ...
                                    ); 
                    end
                    
                case 64
                    for i=0:QamSize-1
                        b = dec2bin(i, obj.Q); 
                        b = double(b(end:-1:1)')-48; 
                        obj.P(i+1) = (1/sqrt(42)) *...
                                     (...
                                        ( (1-2*b(1))*(4-(1-2*b(3))*(2-(1-2*b(5)))) ) +... 
                                      j*( (1-2*b(2))*(4-(1-2*b(4))*(2-(1-2*b(6)))) )  ...
                                      );
                    end

                case 256
                    for i=0:QamSize-1
                        b = dec2bin(i, obj.Q); 
                        b = double(b(end:-1:1)')-48; 
                        obj.P(i+1) = (1/sqrt(170)) *...
                             (...
                                ( (1-2*b(1))*(8-(1-2*b(3))*(4-(1-2*b(5))*(2-(1-2*b(7))))) ) +... 
                              j*( (1-2*b(2))*(8-(1-2*b(4))*(4-(1-2*b(6))*(2-(1-2*b(8))))) )  ...
                              );
                    end
                    
                case 1024
                    for i=0:QamSize-1
                        b = dec2bin(i, obj.Q); 
                        b = double(b(end:-1:1)')-48; 
                       obj.P(i+1) = (1/sqrt(682)) *...
                             (...
                                ( (1-2*b(1))*(16-(1-2*b(3))*(8-(1-2*b(5))*(4-(1-2*b(7))*(2-(1-2*b( 9)))))) ) +... 
                              j*( (1-2*b(2))*(16-(1-2*b(4))*(8-(1-2*b(6))*(4-(1-2*b(8))*(2-(1-2*b(10)))))) )  ...
                              );
                    end
                    
                otherwise,error('QAM constelation not implemented');                                                             
            end
        end

        %%
        %% QAM
        %%
        function v = run_tx(obj,u)

            w=reshape(u,obj.Q, numel(u)/obj.Q);
            for n=1:numel(u)/obj.Q
                pnt = 2.^[0:obj.Q-1] * w(:,n);
                v(n,1) = obj.P(pnt+1);
            end            
        end

        %%
        %% QAM
        %%
        function v = run_rx(obj,u)          
            
            pnts = dec2bin( [0:2^obj.Q-1]' );%define el grid
            for n=0:numel(u)-1                
                for q = 0:obj.Q-1
                    % points where bit q is zero
                    idx0 = find(pnts(:,obj.Q-q)=='0');%define los id donde el bit es 0
                    d0 = abs(u(n+1) - obj.P(idx0)).^2; 

                    % points where bit q is one
                    idx1 = find(pnts(:,obj.Q-q)=='1');
                    d1 = abs(u(n+1) - obj.P(idx1)).^2; 
                    v(obj.Q*n+q +1) = min(d1) - min(d0); % snr scaling not done
                end
                
            end            
        end
        
    end
end

