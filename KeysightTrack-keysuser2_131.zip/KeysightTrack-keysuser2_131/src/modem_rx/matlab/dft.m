function y = dft(x)
% recursive implementation (fft)
    x = x(:);
    N = numel(x);
    
    x0 = x(1:N/2) + x(N/2+1:N);
    x1 = x(1:N/2) - x(N/2+1:N);

    if N == 2
        y0 = x0;
        y1 = x1;
    else
        y0 = dft( x0 );
        n = [0:N/2-1]';
        W = exp(-j*2*pi*n/N);
        y1 = dft( x1 .* W );        
    end
    
    y = [y0.'; y1.']; 
    y = y(:);
end