classdef rm

    properties
        N;
        g0; % first g0 CBs are rate matched to size E0 bits
        g1; % last g1 CBs are rate matched to size E1 bits 
        E0;
        E1;
        C;
    end
    
    methods
        %
        %
        %
        function obj = rm(G,C,N,Q) 
                obj.N = N;
                Q = log2(Q);
                obj.E0 = ceil( (G/Q) / C ) * Q;
                obj.g0 = mod(G/Q, C);
                obj.g1 = C - obj.g0;
                obj.E1 = floor( (G/Q) / C ) * Q;                
                obj.C = C;
                if G ~= obj.E0*obj.g0 + obj.E1*obj.g1, error('something went wrong computing rate matching parameters '); end
        end

        %%
        %% rate matching
        %%
        function v_tx = run_tx(obj,u_tx)

            curPos = 1;
            for g=0:obj.g0-1
               nxtPos = curPos + obj.E0;
               v_tx(curPos:nxtPos-1,1) = u_tx(rem([0:obj.E0-1],obj.N)+1, g+1);
               curPos = nxtPos;
            end
            
            for g=0:obj.g1-1
               nxtPos = curPos + obj.E1;
               v_tx(curPos:nxtPos-1,1) = u_tx(rem([0:obj.E1-1],obj.N)+1, g+obj.g0+1);
               curPos = nxtPos;
            end
            
        end

        %%
        %% inverse rate matching
        %%
        function v_rx = run_rx(obj,u_rx)

            curPos = 1;
            for g=1:obj.g0                
               tmp = u_rx(curPos:curPos+obj.E0-1,1);
               m = 0;
               v_rx(:,g) = zeros(obj.N,1);              

               for k=1:obj.E0
                  v_rx(m+1,g) = v_rx(m+1,g) + tmp(k);
                  m = mod(m+1,obj.N);
               end                   
               curPos = curPos + obj.E0;
            end
            
            for g=1:obj.g1
               tmp = u_rx(curPos:curPos+obj.E1-1,1);
               m = 0;
               v_rx(:,obj.g0+g) = zeros(obj.N,1);              

               for k=1:obj.E1
                  v_rx(m+1,obj.g0+g) = v_rx(m+1,obj.g0+g) + tmp(k);
                  m = mod(m+1,obj.N);
               end                   
               curPos = curPos + obj.E1; 
            end            
        end
        
    end
end

