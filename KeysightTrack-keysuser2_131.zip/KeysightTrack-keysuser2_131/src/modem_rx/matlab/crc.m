classdef crc
    % example for g(x) = 1 + x^5 + x^12 + x^16 => 
    % g = [1 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 1];
    %
    properties
        g; % polynomial
        Deg; % degree 
        C; % encoding matrix
        D; % encoding matrix
        M; % block size for encoding in M by M blocks "per cycle"
    end
    
    methods
        %
        %
        %
        function obj = crc(g,M) 
            obj.M = M;
            obj.g = g;
            obj.Deg = numel(g)-1;
            B = g(2:end)';
            A = eye(obj.Deg, obj.Deg);
            A = [B A(:,1:obj.Deg-1)];

            obj.C = eye(obj.Deg,obj.Deg);
            obj.D = [];
            for m=1:M
              obj.D = mod([obj.C*B obj.D],2);
              obj.C = mod(obj.C*A,2);
            end
            
        end

        %%
        %% CRC encoding
        %%
        function v = run(obj,u)        
            u = u(:);
            N = numel(u);
            K = ceil(N/obj.M); 

            % prefix padding to obtain sequence length multiple of M
            uu = [zeros(K*obj.M- N,1); u];
            uu = reshape(uu, obj.M, K);
            
            % Encoding loop
            p = zeros(obj.Deg,1);            
            w = mod(obj.D * uu,2);
                                               
            for m=1:K
                p = obj.C * p + w(:,m);
                p = mod(p, 2);                  
            end
            
            %% postpend parity and ignore padded prefix
            v = [u; p];            
            
        end
    end 
end

