classdef equ
    properties
        Nfft;
        FreqMask;           % cell BW,  DFT size
        DmrsMask;
        PdchMask;
        dmrs;
    end % of properties

    methods
        %
        %
        function obj = equ(FreqMask,DmrsMask,PdchMask)
                obj.Nfft = numel(FreqMask);
                obj.FreqMask = FreqMask(:);
                obj.DmrsMask = DmrsMask(:);
                obj.PdchMask = PdchMask(:);
                obj.dmrs = dmrs(FreqMask,DmrsMask);
        end
                        
        %
        %
        function v = run(obj,u)            
            idx = find(obj.FreqMask);
            hinv = zeros(obj.Nfft,1);            
            tf_dmrs = run(obj.dmrs);
            for n=1:numel(obj.DmrsMask)                
                if obj.DmrsMask(n) ~= 0
                   % ZF- estimation of inverse channel
                   hinv(idx) = tf_dmrs(idx,n) .*  conj(u(idx,n)) ./ (  u(idx,n) .* conj(u(idx,n)) );
                end
                h(:,n) = hinv;
            end
            
            for n=1:numel(obj.PdchMask)                
                if obj.PdchMask(n) ~= 0
                   % ZF- equalization
                   v(:,n) =  u(:,n)  .*  h(:,n);
                else
                   v(:,n) = u(:,n);
                end
            end
            
            
        end        
        
        %
        %
    end % of methods
end % of class definition


 