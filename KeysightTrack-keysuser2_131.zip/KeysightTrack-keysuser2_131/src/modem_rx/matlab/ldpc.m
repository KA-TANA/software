 classdef ldpc
 
     properties
         K;
         N;
         R;
         Z;
         n;
         k;
         H;
         Nm;
         Mn;
         maxIt = 16;
         kappa = 0.75;
     end
          
     methods
         
         function obj = ldpc()                        
            
            obj.Z = 81;
            obj.R = 5/6;
            obj.H = [...
                13 48 80 66  4 74  7 30 76 52 37 60 -1 49 73 31 74 73 23 -1  1  0 -1 -1;...
                69 63 74 56 64 77 57 65  6 16 51 -1 64 -1 68  9 48 62 54 27 -1  0  0 -1;...
                51 15  0 80 24 25 42 54 44 71 71  9 67 35 -1 58 -1 29 -1 53  0 -1  0  0;...
                16 29 36 41 44 56 59 37 50 24 -1 65  4 65 52 -1  4 -1 73 52  1 -1 -1  0];
                    
            obj.n = numel(obj.H(1,:));
            obj.k = obj.n - numel(obj.H(:,1));            
            
            % we use only first Kb information columns of H1
            % modify matrix to create shortening                        
            obj.N =obj.n * obj.Z;
            obj.K =obj.k * obj.Z;
                            
            for m = 0:obj.n-obj.k-1
                obj.Nm{m+1} = find( obj.H(m+1,:) ~= -1 )-1;
            end
            
            for n = 0:obj.n-1
                obj.Mn{n+1} = find( obj.H(:,n+1) ~= -1 )-1;
            end             
         end
     
     %%
     %% LDPC encoder
     function v = run_tx(obj, u)        
                
        V = zeros(obj.Z, obj.n);
        % copy information to output register
        V(:,1:obj.k) = reshape(u,obj.Z,obj.k);
        
        % compute first parity-check block p0
        % by combining the layers of the H matrix

        for m = 0:obj.n-obj.k-1
            I(:,m+1) = zeros(obj.Z,1);
            for n = 0:numel(obj.Nm{m+1})-1
                if obj.Nm{m+1}(n+1) < obj.k
                    I(:,m+1) = I(:,m+1) + circshift( V(:,obj.Nm{m+1}(n+1)+1), -obj.H(m+1, obj.Nm{m+1}(n+1)+1) );
                end
            end
        end
        I = mod(I,2); 
              
        P = 0;
        tmp = 0;
        for m = 0 : obj.n-obj.k-1
            tmp = tmp + I(:,m+1);
            if obj.H(m+1, obj.k+1) > -1
                P = bitxor(P, obj.H(m+1, obj.k+1));
            end
        end
        tmp = mod(tmp, 2);
        P0 = circshift(tmp, P);
        V(:,obj.k+1) = P0;

        % compute p1, p2,p3,...         
        for m = 0 : obj.n - obj.k - 2
            tmp = I(:,m+1);
            for n = 0:numel(obj.Nm{m+1})-2
                if obj.Nm{m+1}(n+1) >= obj.k
                   tmp = tmp + circshift( V(:,obj.Nm{m+1}(n+1)+1), -obj.H(m+1, obj.Nm{m+1}(n+1)+1) );
                end
            end
            tmp = mod(tmp,2); 
            V(:,obj.k+m+2) = tmp;
        end
      
        v = reshape(V,1, obj.n*obj.Z);
     end
        
 
    %%
    %% LDPC decoder
    %%
    function [u i] = run_rx(obj, r)
        persistent mem
        persistent V
        
        % initiate mems
        V = reshape(r,obj.Z, obj.n);
        for n=0:numel(obj.Mn)-1
            for m=0:numel(obj.Mn{n+1})-1
               mem{obj.Mn{n+1}(m+1)+1,n+1} = zeros(obj.Z,1); 
            end
        end
        
        % Iterate
        for i = 1: obj.maxIt          
            
            for m=0:obj.n-obj.k-1                               
                % CNO fetch                    
                C = zeros( obj.Z, numel(obj.Nm{m+1}) );
                D = zeros( obj.Z, numel(obj.Nm{m+1}) );
                for n=0:numel( obj.Nm{m+1})-1
                    C(:,n+1) = circshift( V(:,obj.Nm{m+1}(n+1)+1), -obj.H(m+1,obj.Nm{m+1}(n+1)+1) );
                    D(:,n+1) = mem{m+1, obj.Nm{m+1}(n+1)+1};
                end    
                
                % CNO Operation
                CmD = C-D;   
                E = cno(obj, CmD);                    
                % store new extrinsics
                for n=0:numel(obj.Nm{m+1})-1
                    mem{m+1, obj.Nm{m+1}(n+1)+1} = E(:,n+1);
                end                                                       
            
                % compute VNO
                F = E - D;
                for n=0:numel(obj.Nm{m+1})-1
                    V(:, obj.Nm{m+1}(n+1)+1) = V(:, obj.Nm{m+1}(n+1)+1) + circshift( F(:,n+1), obj.H(m+1, obj.Nm{m+1}(n+1)+1) );
                end                
            end
            % compute syndrome
            s=zeros(obj.Z,obj.n-obj.k);
            for m=0:obj.n-obj.k-1                               
                for n=0:numel( obj.Nm{m+1})-1
                    s(:,m+1) = s(:,m+1) + circshift( V(:,obj.Nm{m+1}(n+1)+1) < 0, -obj.H(m+1,obj.Nm{m+1}(n+1)+1) );
                end 
            end
            s = mod(s(:),2);
            if (sum(s) == 0), break; end;
    
        end        

        v = reshape( V < 0, 1, obj.n*obj.Z);            
        u = v(1, 1:obj.K);        
    end    
    
    %%
    %% CNO operation : NMS
    %% alternative method just for testing....
    function y = cno(obj, x);
        [N c] = size(x);
        a = zeros(N,c);
        b = zeros(N,c);
        sa = zeros(N,c);
        sb = zeros(N,c);;
        y = zeros(N,c);

        ax = abs(x);
        ax = ax*obj.kappa;

        sx = sign(x);
        clear x
        
        a(:,1) = ax(:,1);
        sa(:,1) = sx(:,1);
        b(:,c) = ax(:,c);
        sb(:,c) = sx(:,c);
        
        for i = 2 : c-1
            a(:,i) = min( a(:,i-1), ax(:,i) );
            sa(:,i) = sa(:,i-1) .* sx(:,i);

            b(:,c+1-i) = min( b(:,c+2-i), ax(:,c+1-i) );
            sb(:,c+1-i) = sb(:,c+2-i) .* sx(:,c+1-i);
        end
        
        for i = 2 : c-1
            y(:,i) = min( a(:,i-1), b(:,i+1) ) .* sa(:,i-1) .* sb(:,i+1);
        end
        y(:,1) = b(:,2) .* sb(:,2);
        y(:,c) = a(:,c-1) .* sa(:, c-1);
    end
    
    
end
     
 end
 
    