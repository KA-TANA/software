%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%   modem OFDM
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all
reset(RandStream.getGlobalStream);  %reinit awgn channel
rng(0);
%
% system configuration
%
% HEAD
snr_db = 20; 

Nfft = 4096;                                % cell BW,  DFT size
cpSize = [768 256 256 256 256 256 256 256 256 256 256 256 256 256];   
Nprb = 256;                                 % channel BW 1PRB = 12 subcarriers
FreqMask = [ones(1,12*Nprb/2)...
            zeros(1,Nfft-12*Nprb)... 
            ones(1,12*Nprb/2)];             % 1x4096 TrBlk and DMRS map in frequency
PdchMask = [0 1 1 1 1 1 1 1 1 1 1 1 1 1];   % 1x14 TrBlk map in time
DmrsMask = [1 0 0 0 0 0 0 0 0 0 0 0 0 0];   % 1x14 DMRS map in time



cfo = 1000;                                  % CFO error in Hz
hchannel = [ 0.1 -0.2 -0.1 0.2 0.1 -0.2 0.3 -1 -0.2 -0.1]/sqrt(1.29);
sto = [0:numel(hchannel)-1] * hchannel' / sum(hchannel); % sto is the "center of gravity of the channel

%QamSize = 2;                                 % QAM  constellation size, 2 = BPSK, 4=QPSK, 16 = QAM16, 64=QAM64, 256 = QAM256 and 1024 = QAM1024
%QamSize = 4;
QamSize = 16;

%QamSize = 64;
%QamSize =256;
%QamSize =1024;
TrBlkSize = floor(4000 * log2(QamSize));     % Size of TrBlk in unit bytes
SlotTime = 250e-6;                           % Slot time duration
global Fs;
Fs = (sum(cpSize)+numel(cpSize)*Nfft)/SlotTime; % required IQ sampling Frequency
Tput = (TrBlkSize * 8)/SlotTime;              % data throughput
CR = (TrBlkSize * 8) / (sum(FreqMask) * sum(PdchMask)*log2(QamSize));
fprintf('----------------------------------------------------\n');
fprintf('| MODEM TEST\n');
fprintf('| Throughput %.2f Mbps\n',Tput/1e6);
fprintf('| Coding Rate = %.2f \n',CR);
fprintf('| QAM%d\n',QamSize);

%------------------------------
% create a modem object
myModem = modem(FreqMask,PdchMask,DmrsMask, TrBlkSize,QamSize, cpSize);

%------------------------------
% generate random TrBlk payload
TrBlk_tx = randi([0 255], TrBlkSize,1);

%------------------------------
% Modulate TrBlk and DMRS
[iq_tx scatter_tx] = run_tx(myModem,TrBlk_tx);

%------------------------------
%simulate with a simple linear channel (FIR)
iq = filter(hchannel,1,iq_tx);

%------------------------------
% simulate an awgn channel
r = awgn(iq,snr_db,'measured');   

%------------------------------
% generate CFO error
t = [0:numel(iq)-1]';
r = r.*exp(j*2*pi*cfo*t/Fs);

%------------------------------
% demodulation of payload
[TrBlk_rx CrcStatus iterations scatter_rx]= run_rx(myModem,r);


%%%%%%
% result presentation
%%%%%%
%%%%%%
figure(1); subplot(211); pwelch(iq_tx,[],[],[],Fs,'centered'); title('Power Spectral Density, transmitted Signal');
figure(1); subplot(212); pwelch(r,[],[],[],Fs,'centered'); title('Power Spectral Density, received Signal');
figure(2); subplot(411); plot([0:numel(iq_tx)-1]*1e6/Fs, real(iq_tx)); title('Transmitted Signal'); xlabel('t/us'); ylabel('Re)');
figure(2); subplot(412); plot([0:numel(iq_tx)-1]*1e6/Fs, imag(iq_tx)); title('Transmitted Signal'); xlabel('t/us');ylabel('Im');
figure(2); subplot(413); plot([0:numel(iq_tx)-1]*1e6/Fs, real(r)); title('Received Signal'); xlabel('t/us'); ylabel('Re');
figure(2); subplot(414); plot([0:numel(iq_tx)-1]*1e6/Fs, imag(r)); title('Received Signal'); xlabel('t/us'); ylabel('Im');
scatterplot(scatter_tx); title('Scatter plot, Transmitted PDCH Signal');
scatterplot(scatter_rx); title('Scatter plot, Received PDCH Signal');

if CrcStatus ~= 0
    fprintf('| CRC error\n');
end
if norm(TrBlk_tx - TrBlk_rx) > 0
    fprintf('| TrBlk data errors\n');
end
if (CrcStatus == 0) 
    if (norm(TrBlk_tx - TrBlk_rx) == 0)
        fprintf('| Execution passed, no errors detected\n');
    end 
end
fprintf('| mean number of ldpc decoding iterations %d\n', round(mean(iterations)));
fprintf('| real      CFO %8.0f, real      STO %.0f Ts  \n',cfo, sto);
fprintf('| estimated CFO %8.0f, estimated STO %.0f Ts  \n',myModem.cexp.cfo*Fs, myModem.cexp.sto);
fprintf('----------------------------------------------------\n');


%------------------------------
% create tv files
cnfg = SlotTime;
cnfg = [cnfg; log2(QamSize)];
cnfg = [cnfg;Nfft];
cnfg = [cnfg;Nprb];
cnfg = [cnfg;numel(cpSize)];
cnfg = [cnfg; cpSize(:)];
cnfg = [cnfg; PdchMask(:)];
cnfg = [cnfg; DmrsMask(:)];
cnfg = [cnfg; TrBlkSize];
cnfg = [cnfg; FreqMask(:)];
cnfg = [cnfg; CrcStatus]; 
cnfg = [cnfg; cfo/Fs];

csvwrite(['../data/tbs_qam' num2str(QamSize) '_' num2str(snr_db) 'dB.csv'],TrBlk_rx);
csvwrite(['../data/iq_qam'  num2str(QamSize) '_' num2str(snr_db) 'dB.csv'],[real(r) imag(r)]);
csvwrite(['../data/tv_qam'  num2str(QamSize) '_' num2str(snr_db) 'dB.csv'],cnfg);

