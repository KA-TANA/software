classdef cexp < handle
    properties        
        cfo;           % cell BW,  DFT size
        Nfft;
        cpSize;
        nSym;
        guard = 16;    % protection guard for ISI
        sto;
        alpha = 0.99;
        marginCp;
    end % of properties

    methods
        %
        %
        function obj = cexp(cpSize, Nfft)
                obj.cfo = 0.0;
                obj.sto = 0.0;
                obj.cpSize = cpSize;
                obj.Nfft = Nfft;
                obj.nSym = numel(cpSize);
                obj.marginCp = min(obj.cpSize)/2;
        end
        %
        %
        %
        %
        function v = run_rx(obj,u)
            u = u(:);
            % compensate cfo
            t = [0: numel(u)-1]';
            v = u.*exp(-j*2*pi*obj.cfo*t);
        end

        function [sto] = run_est(obj,u)
            u = u(:);

            idx = 0;
            xcorr_array = zeros([1 obj.nSym]);
            for n = 1 : obj.nSym

                % extract CP and OFDM symbol tail
                r_cp = u(idx + [1 : obj.cpSize(n)]);
                r_tail = u(idx + [1 : obj.cpSize(n)] + obj.Nfft);

                % Perform cross correlation
                xcorr_array(n) = r_cp((obj.guard + 1) : (end - obj.guard))' * r_tail((obj.guard + 1) : (end - obj.guard));

                idx = idx + obj.cpSize(n) + obj.Nfft;
            end

            % Calculate and update the cfo normalized by the sampling frequency
            newcfo =  angle(sum(xcorr_array)) / (2 * pi * obj.Nfft);


            obj.cfo = (1-obj.alpha)*obj.cfo + obj.alpha*newcfo;
            global Fs
            disp(['Estimated CFO ' num2str(newcfo*Fs) ' Hz.']);

            % STO estimation
            idx = obj.cpSize(1)+obj.Nfft;
            maxSto = max(obj.cpSize(2:end-1));
            xcor = zeros(maxSto+1,1);
            for n = 2 : obj.nSym-1
                for t=-maxSto/2:maxSto/2
                    % extract CP and OFDM symbol tail
                    r_cp   = u(idx + [1 : obj.cpSize(n)] + t);
                    r_tail = u(idx + [1 : obj.cpSize(n)] + t + obj.Nfft);                
                    xcor(t+maxSto/2+1) = xcor(t+maxSto/2+1) + r_cp' * r_tail;                
                end
                idx = idx + obj.cpSize(n) + obj.Nfft;
            end        
            [val pos] = max(abs(xcor));
            newsto = pos - maxSto/2 - 1;
            disp(['Estimated STO ' num2str(newsto) ' Ts']);
            obj.sto = (1-obj.alpha)*obj.sto + obj.alpha*newsto;
            if obj.sto > obj.marginCp,  obj.sto = marginCp; end
            if obj.sto < -obj.marginCp,  obj.sto = -marginCp; end
            sto = round(obj.sto);
        end      
        %
        %
    end % of methods
end % of class definition


 