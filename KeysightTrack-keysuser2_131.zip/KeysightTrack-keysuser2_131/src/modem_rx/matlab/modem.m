classdef modem
    properties
        Nfft;           % cell BW,  DFT size
        Nsym;
        FreqMask;       % channel allocation mask in frequency for data
        PdchMask;       % channel allocation mask in slot for data
        DmrsMask;       % DMRS position mask
        tbs;
        QamSize;   
        dmrs;
        pdch;
        cp;
        equ;
        cexp;
        scatter;
    end % of properties

    methods
        %
        %
        function obj = modem(FreqMask,PdchMask, DmrsMask, TrBlkSize,QamSize, cpSize)
                obj.Nfft = numel(FreqMask);
                obj.FreqMask = FreqMask(:);
                obj.PdchMask = PdchMask(:);
                obj.DmrsMask = DmrsMask(:);
                obj.tbs = TrBlkSize*8;
                obj.QamSize = QamSize;
                obj.Nsym = numel(PdchMask);
                obj.dmrs = dmrs(FreqMask,DmrsMask);
                obj.pdch = pdch(FreqMask,PdchMask, TrBlkSize, QamSize);
                obj.cp = cp(obj.Nfft,obj.Nsym, cpSize);
                % receiver parts
                obj.equ = equ(FreqMask,DmrsMask,PdchMask);
                %
                obj.cexp = cexp(cpSize, obj.Nfft);
        end
        %
        % TX part of the modem
        function [iq scatter] = run_tx(obj, TrBlk)
            disp('modulation of one slot');

            % create empty t/F grid
            % add DMRS T/F grid
            tf_dmrs = run(obj.dmrs);
            % add Data channel T/F grid
            tf_pdch= run_tx(obj.pdch,TrBlk);
            
            % add all t/f grid signals 
            X = tf_dmrs + tf_pdch;
            
            % IDFT
            x = ifft(X);

            % add CP and concatenate to compose iq
            iq = run_tx(obj.cp, x);
            scatter = tf_pdch(:, find(obj.PdchMask));
            scatter = scatter(find(obj.FreqMask),:);
            scatter = scatter(:);
        end
        
        %
        % Rx part of the modem
        function [y crc_status iterations scatter] = run_rx(obj, x)
            
            % STO and CFO estimation
            sto = run_est(obj.cexp, x);
            
            % CFO compensation
            r = run_rx(obj.cexp,x);
            
            % cp removal and sto compensation
            s = run_rx(obj.cp, r, sto);
            
            % dft
            S = fft(s);
            
            % channel equalization
            X = run(obj.equ,S);
            
            % demodulate Data channel 
            [y crc_status iterations]= run_rx(obj.pdch,X);               
            scatter = X(:, find(obj.PdchMask));
            scatter = scatter(find(obj.FreqMask),:);
            scatter = scatter(:);
        end
    end % of methods
end % of class definition
 