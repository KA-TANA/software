classdef golden < handle
    % example for g(x) = 1 + x^18 + x^23 => 
    % g = [1 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1];
    %
    properties
        % g; % polynomial
        % Deg; % degree 
        % B; % encoding matrix
        % A; % encoding matrix
        % C; % encoding matrix
        % D; % encoding matrix
        % M; % block size for encoding in M by M blocks "per cycle"
        % seed;
        g1;
        g2;
        pn1;
        pn2;
    end
    
    methods
        %
        %
        %
        function obj = golden() 
           g1=[1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 1];
           seed1=eye(numel(g1)-1,1);
           
           obj.pn1=pn(g1,2,seed1);

           g2=[1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1];
           % Inicializa la semilla seed2
            
        
            % Calcula la suma ponderada de los bits de x_2 multiplicados por 2^i
           seed2=eye(numel(g1)-1,1);
           %disp(['La semilla seed2 es: ', num2str(seed2)]);
           %seed2=eye(numel(g1)-1,1);
           obj.pn2=pn(g2,2,seed2);
           for n=1:1600
                tmp = obj.pn1.run;
                tmp2= obj.pn2.run;
           end

        end

        
        %%
        %% PN generation
        %%
        function [y, obj] = run(obj)        
            x1 = obj.pn1.run();
            x2=obj.pn2.run();
            y=mod(x1+x2,2);

                    
        end
    end 
end


 