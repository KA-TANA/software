classdef dmrs
    properties
        Nfft;           % cell BW,  DFT size
        FreqMask;        % channel allocation mask in frequency for data
        TimeMask;        % channel allocation mask in slot for data
        Nsym;
        golden;
        QPSK = [1+j; -1+j; 1-j; -1-j]/sqrt(2); 
    end % of properties

    methods
        %
        %
        function obj = dmrs(FreqMask,TimeMask)
                obj.Nfft = numel(FreqMask);
                obj.FreqMask = FreqMask(:);
                obj.Nsym = numel(TimeMask);
                obj.TimeMask = TimeMask(:);

                % PN generator based on g(x) = 1 + x^18 + x^23 => 
                %cambiar g PN-generator 𝑔(𝐷)=1+ 𝐷^18+𝐷^23
                %x1(n)=X(n+3)+X(n+31)-->g(x)=1+x^3+x^31
                %x2(n)--> g(x)=1+x+x^2+x^3+x^31
                
               
                g = [1 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1];                

                
                
                %seed1 = eye(numel(g)-1,1);
                %obj.pn = pn(g,2,seed);   %comentar este
                obj.golden=golden();   %descomentar este


        end
        %
        %
        function X = run(obj)

            disp('DMRS t/f generation...');
            % just a very simple PN sequence mapped as QPSK points on the t/f
            % grid
            % create empty t/F grid
            X = zeros(obj.Nfft,obj.Nsym);
            for t= 1:obj.Nsym
                if obj.TimeMask(t) == 1,
                    for f=1:obj.Nfft
                        if obj.FreqMask(f) == 1, 
                            % generate 2 pn bits
                            %[pnt obj.pn] = obj.pn.run;%comentar este
                            [pnt, obj.golden] = obj.golden.run;%descomentar este
                            % qpsk mapping
                            X(f,t) = obj.QPSK([1 2]*pnt+1);
                        end
                    end
                end
            end
            disp('DMRS t/f generation done!');            
        end
        %
        %
    end % of methods
end % of class definition


 
