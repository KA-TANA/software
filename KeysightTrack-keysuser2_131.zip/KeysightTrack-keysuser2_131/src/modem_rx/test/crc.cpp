#include "crc.hpp"
#include <ctime>
#include <chrono>

using namespace hostCrc;
using namespace std;


// CRC16 polynomial 1 + x^5 + x^12 + x^16
const int C16x8[16] = {273, 546, 1092, 2185, 4098, 8196, 16392, 32785, 35, 70, 140, 8, 17, 34, 68, 136};
const int D16x8[16] = {17, 34, 68, 137, 2, 4, 8, 17, 35, 70, 140, 8, 17, 34, 68, 136};

crc_t::crc_t(int TrBlkLen)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] crc_t constructor entering" << endl;
#endif

    A = TrBlkLen; // TBS length in unit bytes

#ifdef DEBUG_PRINTF
    cout << "[INFO] crc_t constructor exiting" << endl;
#endif
}

crc_t::~crc_t(void)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] crc_t destructor entering" << endl;
    cout << "[INFO] crc_t destructor exiting" << endl;
#endif
}
int crc_t::byteWeight(int input)
{
    int sum = 0;
    for (int n = 0; n < 8; n++)
    {
        sum = (input & (1 << n)) == 0 ? sum : sum + 1;
    }
    return sum;
}
int crc_t::wordWeight(int input)
{
    int sum = 0;
    for (int n = 0; n < 16; n++)
    {
        sum = (input & (1 << n)) == 0 ? sum : sum + 1;
    }
    return sum;
}

void crc_t::run_rx(char *input, int *crc16)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] crc_t run entering" << endl;
#endif
#ifdef CRC_PRINT_TIME
    auto start = std::chrono::high_resolution_clock::now();
#endif


    //
    //  CRC algorithm
    // p is a 16x1 binary vector containing the computed CRC16
    // C is a 16x16 binary matrix
    // D is a 8x16 binary matrix
    // u[n] is a 8x1 binary vector contains information bits of the n'th byte
    //
    //  CRC16 encoding loop will be
    //
    //  p = [0,0,...,0]';
    //  for n=1:A
    //      p = C * p + D * u[n]; // GF(2) operations always (mod 2 algebra)
    //  end
    //
    int p = 0;
    for (int n = 0; n < A; n++)
    {
        int u = 0x00FF & (int)input[n];
        // compute w = D*u
        int w = 0;
        for (int k = 0; k < 16; k++)
        {
            w |= (byteWeight(D16x8[k] & u) % 2) << k;
        }
        // compute z = C * p
        int z = 0;
        for (int k = 0; k < 16; k++)
        {
            z |= (wordWeight(C16x8[k] & p) % 2) << k;
        }
        p = z ^ w;
    }
    *crc16 = p;


#ifdef CRC_PRINT_TIME
    auto stop = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> delta = stop - start;
    std::chrono::microseconds timeMicroSec = std::chrono::duration_cast<std::chrono::microseconds>(delta);
    std::cout << "[INFO] CPU crcCompute execution time " << timeMicroSec.count() << "us\n";
#endif
#ifdef DEBUG_PRINTF
    cout << "[INFO] crc_t run exiting" << endl;
#endif
};
