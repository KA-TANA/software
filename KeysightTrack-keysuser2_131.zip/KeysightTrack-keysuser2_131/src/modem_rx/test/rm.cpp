#include "rm.hpp"
#include <ctime>
#include <chrono>

using namespace hostRm;
using namespace cudaQam;
using namespace std;

rm_t::rm_t(int G, int C, int codeBlockLength, const_t qamType)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] rm_t constructor entering" << endl;
#endif

    int Q = (int)qamType;
    E0 = (((G / (int)Q) + C - 1) / C) * (int)Q;
    g0 = (G / (int)Q) % C;
    g1 = C - g0;
    E1 = ((G / (int)Q) / C) * (int)Q;
    N = codeBlockLength;

#ifdef DEBUG_PRINTF
    cout << "[INFO] rm_t constructor exiting" << endl;
#endif
}

rm_t::~rm_t(void)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] rm_t destructor entering" << endl;
    cout << "[INFO] rm_t destructor exiting" << endl;
#endif
}

void rm_t::run_rx(float *input, float *output)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] rm_t run_rx entering" << endl;
#endif
#ifdef RM_PRINT_TIME
    auto start = std::chrono::high_resolution_clock::now();
#endif

    for (int n = 0; n < g0; n++)
    {
        int m = 0;
        for (int k = 0; k < N; k++) output[k] = 0.0;
        for (int k = 0; k < E0; k++)
        {
            output[m] += input[k];
            m = (m + 1) % N;
        }
        input += E0;
        output += N;
    }

    for (int n = 0; n < g1; n++)
    {
        int m = 0;
        for (int k = 0; k < N; k++) output[k] = 0.0;
        for (int k = 0; k < E1; k++)
        {
            output[m] += input[k];
            m = (m + 1) % N;
        }
        input += E1;
        output += N;
    }

#ifdef RM_PRINT_TIME
    auto stop = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> delta = stop - start;
    std::chrono::microseconds timeMicroSec = std::chrono::duration_cast<std::chrono::microseconds>(delta);
    std::cout << "[INFO] CPU rm run_rx execution time " << timeMicroSec.count() << "us\n";
#endif
#ifdef DEBUG_PRINTF
    cout << "[INFO] rm_t run_rx exiting" << endl;
#endif
};

// debug utility
void rm_t::print(float *output)
{
    printf("[DEBUG] rm config g0 = %d, E0 = %d, g1 = %d, E1 = %d, N = %d\n", g0, E0, g1, E1, N);

#define LIST_LEN 4

    for (int c = 0; c < g0 + g1; c++)
    {
        printf("[DEBUG] rm_output[%d][0:%d] = ", c, N - 1);
        for (int n = 0; n < LIST_LEN; n++) printf("%.4f,", output[n]);
        printf(",..........,");
        for (int n = N - LIST_LEN; n < N - 1; n++) printf("%.4f,", output[n]);
        printf("%.4f.\n", output[N - 1]);

        output += N;
    }
}
