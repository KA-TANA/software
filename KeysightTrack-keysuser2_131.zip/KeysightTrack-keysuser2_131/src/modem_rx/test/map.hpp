#pragma once
#include "mtypes.hpp"

#ifdef PRINT_EXECUTION_TIMES
#define MAP_PRINT_TIME
#endif

namespace hostMap
{

class map_t
{
public:
    int nFFT;
    int nSym;
    bool *FreqMask;
    bool *TimeMask;

    // constructor
    map_t() = delete;
    map_t(int FFTSize, int nSymbol, bool *freqMask, bool *timeMask);

    // destructor
    virtual ~map_t();

    void run_rx(complex_t *input, complex_t *output);
};

}
