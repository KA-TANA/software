#include "modem.hpp"
#include <ctime>
#include <chrono>

using namespace hostModem;
using namespace std;

// constructor
modem_t::modem_t(int fftSize,
                 int nSymbols,
                 bool *freqMask,
                 bool *pdchMask,
                 bool *dmrsMask,
                 int trBlkSize,
                 int qamSize,
                 int *cpSizes)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] modem_t constructor entering" << endl;
#endif

    nFFT = fftSize;
    nSym = nSymbols;
    FreqMask = new bool[fftSize];
    for (int n = 0; n < fftSize; n++)
    {
        FreqMask[n] = freqMask[n];
    }

    PdchMask = new bool[nSymbols];
    DmrsMask = new bool[nSymbols];
    for (int n = 0; n < nSymbols; n++)
    {
        PdchMask[n] = pdchMask[n];
        DmrsMask[n] = dmrsMask[n];
    }
    TrBlkSize = trBlkSize;

    // setup cexp object
    cexp = new cexp_t(fftSize, nSymbols, cpSizes);
    // setup cp object
    cp = new cp_t(fftSize, nSymbols, cpSizes);
    // setup pdch object
    pdch = new pdch_t(fftSize, nSymbols, freqMask, pdchMask, (const_t)qamSize, trBlkSize);
    // setup pdch object
    equ = new equ_t(fftSize, nSymbols, freqMask, dmrsMask, pdchMask);
    // setup dft object
    dft = new dft_t(nSymbols,fftSize);

    int slotSize = 0;
    for (int n = 0; n < nSym; n++)
    {
        slotSize += (nFFT + cpSizes[n]);
    }
    cp_input = new complex_t[slotSize];
    fft_input = new complex_t[nSymbols * nFFT];
    fft_output = new complex_t[nSymbols * nFFT];
    equ_output = new complex_t[nSymbols * nFFT];

#ifdef DEBUG_PRINTF
    cout << "[INFO] modem_t constructor exiting" << endl;
#endif
}

// destructor
modem_t::~modem_t()
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] modem_t destructor entering" << endl;
#endif

    delete[] equ_output;
    delete[] fft_output;
    delete[] fft_input;
    delete[] cp_input;

    delete dft;
    delete equ;
    delete pdch;
    delete cp;
    delete cexp;
    delete[] DmrsMask;
    delete[] PdchMask;
    delete[] FreqMask;

#ifdef DEBUG_PRINTF
    cout << "[INFO] modem_t destructor exiting" << endl;
#endif
}

// Demodulate slot
void modem_t::run_rx(complex_t *rx_iq, char *rx_data, bool *crcStatus, int *iterations)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] modem_t run_rx  entering" << endl;
#endif
#ifdef MODEM_PRINT_TIME
    auto start = std::chrono::high_resolution_clock::now();
#endif
    // cfo and sto estimation
    float sto;
    sto = cexp->run_est(rx_iq);

    // cfo compensation
    cexp->run_rx(rx_iq, cp_input);

    // cp removal and sto compensation
    cp->run_rx(cp_input, fft_input, sto);

    // fft
    dft->run_fft(fft_input, fft_output);

    //    channel estimation
    equ->run_est(fft_output);

    //    channel equalization
    equ->run(fft_output, equ_output);

    // demodulate Data
    pdch->run_rx(equ_output, rx_data, crcStatus, iterations);

#ifdef MODEM_PRINT_TIME
    auto stop = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> delta = stop - start;
    std::chrono::microseconds timeMicroSec = std::chrono::duration_cast<std::chrono::microseconds>(delta);
    std::cout << "[INFO] CPU modem run_rx execution time " << timeMicroSec.count() << "us\n";
#endif

#ifdef DEBUG_PRINTF
    cout << "[INFO] modem_t run_rx  exiting" << endl;
#endif
};
