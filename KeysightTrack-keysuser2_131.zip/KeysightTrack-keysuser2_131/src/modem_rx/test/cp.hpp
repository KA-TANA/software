#pragma once
#include "mtypes.hpp"

#ifdef PRINT_EXECUTION_TIMES
#define CP_PRINT_TIME
#endif


namespace hostCp
{

class cp_t
{
public:
    int nFFT;         // cell BW,  DFT size
    int nSym;         // slot size in OFDM symbols
    int *cpSizeArray; // cpSizeArray[0:nSym-1] are the CP sizes for symbols 0:nSym-1
    int marginCp;     // margin against estimation STO errors

    // constructor
    cp_t() = delete;
    cp_t(int FFTSize, int nSymbol, int *cpSizes);

    // destructor
    virtual ~cp_t();

    // cp removal
    void run_rx(complex_t *input, complex_t *output, float sto);
};

}
