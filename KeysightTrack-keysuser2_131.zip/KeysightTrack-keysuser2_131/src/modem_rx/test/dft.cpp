#include "dft.hpp"
#include <cmath>
#include <ctime>
#include <chrono>

using namespace hostDft;
using namespace std;


dft_t::dft_t(int nSymbols, int size)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] dft_t constructor entering" << endl;
#endif

    dftSize = size;
    nSymb = nSymbols;

    // Tabulate twiddle factor table
    W = new complex_t[size];
    float pi = std::numbers::pi;
    for (int N = 1; N < 2 * size; N *= 2)
    {
        for (int n = 0; n < N / 2; n++)
        {
            float phase = -2.0 * pi * (float)n / (float)N;
            W[N / 2 + n].real = cos(phase);
            W[N / 2 + n].imag = sin(phase);
        }
    }

#ifdef DEBUG_PRINTF
    cout << "[INFO] dft_t constructor exiting" << endl;
#endif
}

dft_t::~dft_t(void)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] dft_t destructor entering" << endl;
#endif

    delete[] W;
#ifdef DEBUG_PRINTF
    cout << "[INFO] dft_t destructor exiting" << endl;
#endif
}


void dft_t::fft_recursion(complex_t *input, complex_t *output, int nFFT)
{
    complex_t *x0 = new complex_t[2 * nFFT];
    complex_t *x1 = x0 + nFFT / 2;
    complex_t *y0 = x0 + nFFT;
    complex_t *y1 = x0 + nFFT + nFFT / 2;

    for (int n = 0; n < nFFT / 2; n++)
    {
        x0[n] = input[n] + input[n + nFFT / 2];
        x1[n] = input[n] - input[n + nFFT / 2];
    }

    if (nFFT == 2)
    {
        y0[0] = x0[0];
        y1[0] = x1[0];
    }
    else
    {
        fft_recursion(x0, y0, nFFT / 2);
        for (int n = 0; n < nFFT / 2; n++)
        {
            x1[n] = x1[n] * W[n + nFFT / 2];
        }
        fft_recursion(x1, y1, nFFT / 2);
    }

    for (int n = 0; n < nFFT / 2; n++)
    {
        output[2 * n + 0] = y0[n];
        output[2 * n + 1] = y1[n];
    }

    delete[] x0;
};

void dft_t::run_fft(complex_t *input, complex_t *output)
{
#ifdef DFT_PRINT_TIME
    auto start = std::chrono::high_resolution_clock::now();
#endif

    for (int n = 0; n < nSymb; n++) fft_recursion(input + n * dftSize, output + n * dftSize, dftSize);

#ifdef DFT_PRINT_TIME
    auto stop = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> delta = stop - start;
    std::chrono::microseconds timeMicroSec = std::chrono::duration_cast<std::chrono::microseconds>(delta);
    std::cout << "[INFO] CPU dft run_fft execution time " << timeMicroSec.count() << "us\n";
#endif
}
