#include "dmrs.hpp"
#include <cmath>
#include <ctime>
#include <chrono>

using namespace hostDmrs;
using namespace std;

dmrs_t::dmrs_t(int FFTSize, int nSymbol, bool *freqMask, bool *timeMask)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] dmrs_t constructor entering" << endl;
#endif

    nFFT = FFTSize;
    nSym = nSymbol;
    FreqMask = freqMask;
    TimeMask = timeMask;
    qpsk[0].real = 1.0;
    qpsk[0].imag = 1.0;
    qpsk[1].real = -1.0;
    qpsk[1].imag = 1.0;
    qpsk[2].real = 1.0;
    qpsk[2].imag = -1.0;
    qpsk[3].real = -1.0;
    qpsk[3].imag = -1.0;
    qpsk[0] = qpsk[0] / sqrt(2.0);
    qpsk[1] = qpsk[1] / sqrt(2.0);
    qpsk[2] = qpsk[2] / sqrt(2.0);
    qpsk[3] = qpsk[3] / sqrt(2.0);

    bool seed[23] = {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    pn = new pn_t(seed);

#ifdef DEBUG_PRINTF
    cout << "[INFO] dmrs_t constructor exiting" << endl;
#endif
}

dmrs_t::~dmrs_t(void)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] dmrs_t destructor entering" << endl;
#endif

    delete pn;

#ifdef DEBUG_PRINTF
    cout << "[INFO] dmrs_t destructor exiting" << endl;
#endif
}

void dmrs_t::run(complex_t *output)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] dmrs_t run entering" << endl;
#endif
#ifdef DMRS_PRINT_TIME
    auto start = std::chrono::high_resolution_clock::now();
#endif

    for (int n = 0; n < nSym; n++)
    {
        for (int k = 0; k < nFFT; k++)
        {
            if (TimeMask[n] && FreqMask[k])
            {
                int digit[2];
                pn->run(digit);
                output[n * nFFT + k] = qpsk[digit[0] + 2 * digit[1]];
            }
            else
            {
                output[n * nFFT + k].real = 0.0;
                output[n * nFFT + k].imag = 0.0;
            }
        }
    }

#ifdef DMRS_PRINT_TIME
    auto stop = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> delta = stop - start;
    std::chrono::microseconds timeMicroSec = std::chrono::duration_cast<std::chrono::microseconds>(delta);
    std::cout << "[INFO] CPU dmrs run execution time " << timeMicroSec.count() << "us\n";
#endif
#ifdef DEBUG_PRINTF
    cout << "[INFO] dmrs_t run exiting" << endl;
#endif
};
