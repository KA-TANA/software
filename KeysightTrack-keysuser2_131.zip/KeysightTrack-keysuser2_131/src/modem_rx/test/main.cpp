#include <iostream>
#include <fstream>
#include "tv.hpp"
#include "modem.hpp"
#include <ctime>
#include <chrono>

using namespace hostModem;
using namespace std;

// Meson defines for test error results
#define TEST_OK 0
#define TEST_ERROR 1
#define TEST_SKIP 77

int main(int argc, char **argv)
{
    tv_t tv(argv);

    //-----------------------
    // create modem object
    //
    modem_t myModem(tv.nFFT, tv.nSym, tv.FreqMask, tv.PdchMask, tv.DmrsMask, tv.TrBlkSize, tv.QamSize, tv.cpSizes);

    //-------------------
    // demodulate IQ
    //
    bool crcStatus = TEST_ERROR;
    int avgIter;

    auto start = chrono::high_resolution_clock::now();
    myModem.run_rx(tv.rx_iq, tv.rx_payload, &crcStatus, &avgIter);
    auto stop = chrono::high_resolution_clock::now();
    chrono::duration<double> delta = stop - start;
    chrono::microseconds timeMicroSec = chrono::duration_cast<std::chrono::microseconds>(delta);

    //------------------
    // Make conclusions: FAIL or PASSED
    //
    bool error = TEST_OK;
    if (crcStatus != tv.ShouldBeCRCError)
    {
        printf("\n[INFO] CRC check ERROR\n");
        error = TEST_ERROR;
    }
    // check payload only when CRC is ok, otherwise it makes no sense
    if (tv.check_modem_rx_data(argv) == TEST_ERROR)
    {
        printf("\n[INFO] PAYLOAD RECEPTION ERROR\n");
        error = TEST_ERROR;
    }

    if (error == TEST_ERROR) printf("\n[INFO] modem test ERROR\n\n\n");
    if (error == TEST_OK) 
    {
        printf("\n[INFO] ===============================================================\n");
        printf("[INFO] ||                MODEM TEST    PASSED                       ||\n");
        printf("[INFO] || Average number of LDPC decoding iterations  I = %6d    ||\n", avgIter);
        printf("[INFO] || Slot duration                           Tslot = %6.0f us ||\n",(float) tv.slotTime / 1e-6);
        printf("[INFO] || Modem run_rx execution time             Texec = %6.0f us ||\n",(float) timeMicroSec.count());
        printf("[INFO] || Texec/Tslot                             Ratio = %6.0f    ||\n",(float) timeMicroSec.count()/(tv.slotTime / 1e-6) );
        printf("[INFO] ===============================================================\n\n\n");
    }
    
    return (error) ? TEST_ERROR : TEST_OK;
}