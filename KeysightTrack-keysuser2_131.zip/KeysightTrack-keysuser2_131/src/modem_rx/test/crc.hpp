#pragma once
#include "mtypes.hpp"

#ifdef PRINT_EXECUTION_TIMES
#define CRC_PRINT_TIME
#endif

namespace hostCrc
{

class crc_t
{
public:
    int A;
    // constructor
    crc_t() = delete;
    crc_t(int TrBlkLen);

    // destructor
    virtual ~crc_t();

    void run_rx(char *input, int *crc16);

private:
    int byteWeight(int input);
    int wordWeight(int input);
};

}
