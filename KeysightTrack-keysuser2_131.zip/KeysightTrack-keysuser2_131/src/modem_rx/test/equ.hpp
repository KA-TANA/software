#pragma once
#include "mtypes.hpp"
#include "dmrs.hpp"

#ifdef PRINT_EXECUTION_TIMES
#define EQU_PRINT_TIME
#endif

namespace hostEqu
{

using namespace hostDmrs;


class equ_t
{
public:
    int nFFT;
    int nSym;
    bool *FreqMask;
    bool *DmrsMask;
    bool *PdchMask;
    dmrs_t *dmrs;
    complex_t *dmrs_output;
    complex_t *Hinv;
    complex_t *hinv;
    // constructor
    equ_t() = delete;
    equ_t(int fftSize, int nSymbols, bool *freqMask, bool *dmrsMask, bool *pdchMask);

    // destructor
    virtual ~equ_t();

    void run_est(complex_t *input);
    void run(complex_t *input, complex_t *output);
};

}
