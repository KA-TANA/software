#include "inter.hpp"
#include <ctime>
#include <chrono>

using namespace hostInter;
using namespace std;

inter_t::inter_t(int G, int C, const_t qamType)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] inter_t constructor entering" << endl;
#endif

    Q = qamType;
    E0 = (((G / (int)Q) + C - 1) / C) * (int)Q;
    g0 = (G / (int)Q) % C;
    g1 = C - g0;
    E1 = ((G / (int)Q) / C) * (int)Q;

#ifdef DEBUG_PRINTF
    cout << "[INFO] inter_t constructor exiting" << endl;
#endif
}

inter_t::~inter_t(void)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] inter_t destructor entering" << endl;
    cout << "[INFO] inter_t destructor exiting" << endl;
#endif
}
void inter_t::run_rx(float *input, float *output)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] inter_t run_rx entering" << endl;
#endif
#ifdef INTER_PRINT_TIME
    auto start = std::chrono::high_resolution_clock::now();
#endif

    for (int n = 0; n < g0; n++)
    {
        int c = 0;
        int r = 0;
        for (int k = 0; k < E0; k++)
        {
            r = k % Q;
            c = k / Q;
            output[r * E0 / Q + c] = input[k];
        }
        input += E0;
        output += E0;
    }
    for (int n = 0; n < g1; n++)
    {
        int c = 0;
        int r = 0;
        for (int k = 0; k < E1; k++)
        {
            r = k % Q;
            c = k / Q;
            output[r * E1 / Q + c] = input[k];
        }
        input += E1;
        output += E1;
    }

#ifdef INTER_PRINT_TIME
    auto stop = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> delta = stop - start;
    std::chrono::microseconds timeMicroSec = std::chrono::duration_cast<std::chrono::microseconds>(delta);
    std::cout << "[INFO] CPU inter run_rx execution time " << timeMicroSec.count() << "us\n";
#endif
#ifdef DEBUG_PRINTF
    cout << "[INFO] inter_t run_rx exiting" << endl;
#endif
};

// debug utility
void inter_t::print(float *output)
{
    printf("[DEBUG] inter config g0 = %d, E0 = %d, g1 = %d, E1 = %d, Q = %d\n", g0, E0, g1, E1, Q);

#define LIST_LEN 4

    for (int c = 0; c < g0; c++)
    {
        printf("[DEBUG] inter_output[%d][0:%d] = ", c, E0 - 1);
        for (int n = 0; n < LIST_LEN; n++) printf("%.4f,", output[n]);
        printf(",..........,");
        for (int n = E0 - LIST_LEN; n < E0 - 1; n++) printf("%.4f,", output[n]);
        printf("%.4f.\n", output[E0 - 1]);

        output += E0;
    }
    for (int c = 0; c < g1; c++)
    {
        printf("[DEBUG] inter_output[%d][0:%d] = ", c + g0, E1 - 1);
        for (int n = 0; n < LIST_LEN; n++) printf("%.4f,", output[n]);
        printf(",..........,");
        for (int n = E1 - LIST_LEN; n < E1 - 1; n++) printf("%.4f,", output[n]);
        printf("%.4f.\n", output[E1 - 1]);

        output += E1;
    }
}
