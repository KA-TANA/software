#include "cp.hpp"
#include <ctime>
#include <chrono>

using namespace hostCp;
using namespace std;

cp_t::cp_t(int FFTSize, int nSymbol, int *cpSizes)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] cp_t constructor entering" << endl;
#endif

    nFFT = FFTSize;
    nSym = nSymbol;
    cpSizeArray = cpSizes;
    marginCp = cpSizes[0];
    for (int n = 0; n < nSymbol; n++)
    {
        marginCp = marginCp < cpSizes[n] / 2 ? marginCp : cpSizes[n] / 2;
    }

#ifdef DEBUG_PRINTF
    cout << "[INFO] cp_t constructor exiting" << endl;
#endif
}

cp_t::~cp_t(void)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] cp_t destructor entering" << endl;
    cout << "[INFO] cp_t destructor exiting" << endl;
#endif
}

void cp_t::run_rx(complex_t *input, complex_t *output, float sto)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] cp_t run_rx  entering" << endl;
#endif
#ifdef CP_PRINT_TIME
    auto start = std::chrono::high_resolution_clock::now();
#endif

    input += ((int)(sto + 0.5) - marginCp); // STO compensation
    for (int k = 0; k < nSym; k++)
    {
        input += cpSizeArray[k];
        for (int n = 0; n < nFFT; n++)
        {
            output[n] = input[n];
        }
        input += nFFT;
        output += nFFT;
    }

#ifdef CP_PRINT_TIME
    auto stop = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> delta = stop - start;
    std::chrono::microseconds timeMicroSec = std::chrono::duration_cast<std::chrono::microseconds>(delta);
    std::cout << "[INFO] CPU cp run_rx execution time " << timeMicroSec.count() << "us\n";
#endif

#ifdef DEBUG_PRINTF
    cout << "[INFO] cp_t run_rx  exiting" << endl;
#endif
};
