#pragma once
#include <iostream>
#include "mtypes.hpp"

//#ifdef PRINT_EXECUTION_TIMES
#define LDPC_PRINT_TIME
//#endif

namespace hostLdpc
{

#define MAXZ 81
#define MINK 4
#define MAXN 24
#define LDPC_INFTY 1.0e10
class ldpc_t
{
public:
    int nCBs;
    int Z;
    float R;
    int H[MAXN - MINK][MAXN];
    int K;
    int N;
    int n;
    int k;
    // decoder variables
    float *mem[MAXN - MINK][MAXN];
    float *V[MAXN];
    int maxIt = 16;
    float *C[MAXN];
    float *CmD[MAXN];
    float *E[MAXN];
    float *F[MAXN];
    float *G[MAXN];
    bool S[MAXZ];
    float kappa = 0.75;

    // constructor
    ldpc_t() = delete;
    ldpc_t(int C);

    // destructor
    virtual ~ldpc_t();

    void run_rx(float *input, char *output, int *avgIter);
    void print(char *output);

private:
    int decode(float *input, char *output);
    // function for processing llr vector of dim Zx1
    void llr_copy(float *input, float *output);
    void llr_set(float *output, float setValue);
    void llr_hrd(float *input, char *output);
    void llr_rotate(float *input, float *output, int shift);
    int llr_syndrome(float *input, bool *output, int shift);
    void llr_clear(bool *output);
    void llr_sub(float *input1, float *input2, float *output);
    void llr_add(float *input1, float *input2, float *output);
    void llr_minsum(float *input, float *output);
    void llr_scale(float *output, float scale);
    void llr_print(float *input);
    void bit_print(char *input);
};

}