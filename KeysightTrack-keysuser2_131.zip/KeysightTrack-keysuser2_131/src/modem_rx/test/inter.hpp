#pragma once
#include "mtypes.hpp"
#include "qam.hpp"
#include "cudaQam.cuh"

#ifdef PRINT_EXECUTION_TIMES
#define INTER_PRINT_TIME
#endif

namespace hostInter
{

using namespace cudaQam;

class inter_t
{
public:
    int E0;
    int E1;
    int g0;
    int g1;
    int Q;

    // constructor
    inter_t() = delete;
    inter_t(int G, int C, const_t qamType);

    // destructor
    virtual ~inter_t();

    void run_rx(float *input, float *output);
    void print(float *output);
};

}
