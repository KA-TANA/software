#pragma once
#include "mtypes.hpp"

#ifdef PRINT_EXECUTION_TIMES
#define QAM_PRINT_TIME
#endif

namespace hostQam
{

#define INFTY 1.0e10
typedef enum
{
    BPSK = 1,
    QPSK = 2,
    QAM16 = 4,
    QAM64 = 6,
    QAM256 = 8,
    QAM1024 = 10
} const_t;

class qam_t
{
public:
    const_t Q;
    float P[32];
    int nRe;

    // constructor
    qam_t() = delete;
    qam_t(const_t q, int nElements);

    // destructor
    virtual ~qam_t();

    void run_rx(complex_t *input, float *output);
    void print(float *output);

private:
    void run_rxqam1024(complex_t *input, float *output);
    void run_rxqam256(complex_t *input, float *output);
    void run_rxqam64(complex_t *input, float *output);
    void run_rxqam16(complex_t *input, float *output);
    void run_rxqam4(complex_t *input, float *output);
    void run_rxqam2(complex_t *input, float *output);
};

}
