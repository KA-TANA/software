#pragma once
#include <iostream>
#include <cuda_runtime.h>
#include "mtypes.hpp"
#include "cexp.hpp"
#include "cp.hpp"
#include "pdch.hpp"
#include "equ.hpp"
#include "dft.hpp"
#include "cudaDft.cuh"
#include "cudaQam.cuh"

#ifdef PRINT_EXECUTION_TIMES
#define MODEM_PRINT_TIME
#endif


namespace hostModem
{

using namespace hostDft;
//using namespace cudaDft;

using namespace hostCexp;
using namespace hostCp;
using namespace hostPdch;
using namespace hostEqu;
//using namespace hostQam;
using namespace cudaQam;

class modem_t
{
public:
    int nFFT;       // cell BW,  DFT size
    int nSym;       //
    bool *FreqMask; // channel allocation mask in frequency for data
    bool *PdchMask; // channel allocation mask in slot for data
    bool *DmrsMask; // DMRS position mask
    int TrBlkSize;  // TrBlk size in unit bytes

    complex_t *cp_input;
    complex_t *fft_input;
    complex_t *fft_output;
    complex_t *equ_output;

    // sub classes
    cexp_t *cexp;
    cp_t *cp;
    pdch_t *pdch;
    equ_t *equ;
    dft_t *dft;

    // constructor
    modem_t(int fftSize,
            int nSymbols,
            bool *freqMask,
            bool *pdchMask,
            bool *dmrsMask,
            int TrBlkSize,
            int QamSize,
            int *cpSizes);

    // destructor
    virtual ~modem_t();

    // demodulate slot
    void run_rx(complex_t *rx_iq, char *rx_data, bool *crcStatus, int *iterations);
};

}
