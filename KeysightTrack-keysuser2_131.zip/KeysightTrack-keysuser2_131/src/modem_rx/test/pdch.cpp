#include "pdch.hpp"
#include <ctime>
#include <chrono>

using namespace hostPdch;
using namespace std;

pdch_t::pdch_t(int FFTSize, int nSymbol, bool *freqMask, bool *pdchMask, const_t qamType, int trBlkSize)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] pdch_t constructor entering" << endl;
#endif

    nFFT = FFTSize;
    nSym = nSymbol;
    FreqMask = freqMask;
    TimeMask = pdchMask;
    QamType = qamType;

    nRe = 0;
    for (int n = 0; n < nSymbol; n++)
        for (int k = 0; k < nFFT; k++)
        {
            nRe = (FreqMask[k] && TimeMask[n]) ? nRe + 1 : nRe;
        }

    G = nRe * (int)QamType;

    A = trBlkSize * 8;
    int B = A + 16;

    crc = new crc_t(trBlkSize);

    CodeBlockLength = 24 * 81;
    C = (B + 20 * 81 - 1) / (20 * 81);
    ldpc = new ldpc_t(C);

    pad = new pad_t(C, B, 20 * 81);
    rm = new rm_t(G, C, CodeBlockLength, qamType);
    inter = new inter_t(G, C, qamType);
    qam = new qam_t(qamType, nRe);
    map = new map_t(nFFT, nSym, FreqMask, TimeMask);


    map_output = new complex_t[nRe];
    qam_output = new float[G];
    inter_output = new float[G];
    rm_output = new float[C * CodeBlockLength];
    ldpc_output = new char[C * 20 * 81];
    cuda_ldpc_output = new char[C * 20 * 81];
    pad_output = new char[C * B];

#ifdef DEBUG_PRINTF
    cout << "[INFO] pdch_t constructor exiting" << endl;
#endif
}

pdch_t::~pdch_t(void)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] pdch_t destructor entering" << endl;
#endif
    delete pad_output;
    delete cuda_ldpc_output;
    delete ldpc_output;
    delete rm_output;
    delete inter_output;
    delete qam_output;
    delete map_output;
    delete map;
    delete qam;
    delete inter;
    delete rm;
    delete pad;
    delete ldpc;
    delete crc;

#ifdef DEBUG_PRINTF
    cout << "[INFO] pdch_t destructor exiting" << endl;
#endif
}

void pdch_t::run_rx(complex_t *input, char *output, bool *crcStatus, int *iterations)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] pdch_t run_rx entering" << endl;
#endif
#ifdef PDCH_PRINT_TIME
    auto start = std::chrono::high_resolution_clock::now();
#endif

    // demapping
    map->run_rx(input, map_output);

    // QAM demodulation
    qam->run_rx(map_output, qam_output);
    // qam->print(qam_output);

    // inverse Interleaver
    inter->run_rx(qam_output, inter_output);
    //inter->print(inter_output);

    // inverse Rate Matching
    rm->run_rx(inter_output, rm_output);
    //rm->print(rm_output);

    // LDPC decoding
    ldpc->run_rx(rm_output, ldpc_output, iterations);
    //ldpc->print(ldpc_output);

    // Remove Padding bits
    pad->run_rx(ldpc_output, pad_output);
    //pad->print(pad_output);

    // convert received information bit stream to a byte stream
    bit2byte(pad_output, output);
    //print(output);

    // compute CRC16
    int crc16Computed;
    crc->run_rx(output, &crc16Computed);
#ifdef DEBUG_PRINTF
    printf("[INFO] crc16Computed = %X\n", crc16Computed);
#endif

    // convert received CRC to int
    int crc16Received = 0;
    for (int n = 0; n < 16; n++)
    {
        crc16Received |= (pad_output[A + n]) == 0 ? 0 : (1 << n);
    }
    *crcStatus = crc16Computed != crc16Received;

#ifdef PDCH_PRINT_TIME
    auto stop = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> delta = stop - start;
    std::chrono::microseconds timeMicroSec = std::chrono::duration_cast<std::chrono::microseconds>(delta);
    std::cout << "[INFO] CPU pdch run_rx execution time " << timeMicroSec.count() << "us\n";
#endif
#ifdef DEBUG_PRINTF
    cout << "[INFO] pdch_t run_rx exiting " << endl;
#endif
}

void pdch_t::bit2byte(char *input, char *output)
{
    for (int n = 0; n < A; n++)
    {
        int nMod8 = n % 8;
        int nDiv8 = n / 8;
        char bit = input[n];
        output[nDiv8] = (nMod8 == 0) ? bit : output[nDiv8] | (bit << nMod8);
    }
}

void pdch_t::print(char *input)
{
#define LIST_LEN 16
    printf("[DEBUG] pdch_print[0:%d] = ", A / 8 - 1);
    for (int n = 0; n < LIST_LEN; n++) printf("%u,", 0x00FF & (int)input[n]);
    printf(",..........,");
    for (int n = A / 8 - LIST_LEN; n < A / 8 - 1; n++) printf("%u,", 0x00FF & (int)input[n]);
    printf("%u.\n", 0x00FF & (int)input[A / 8 - 1]);
};
