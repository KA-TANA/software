#include "ldpc.hpp"
#include <ctime>
#include <chrono>

using namespace hostLdpc;
using namespace std;

// clang-format off
const int H5R6z81[4*24] = {
                13, 48, 80, 66,  4, 74,  7, 30, 76, 52, 37, 60, -1, 49, 73, 31, 74, 73, 23, -1,  1,  0, -1, -1,
                69, 63, 74, 56, 64, 77, 57, 65,  6, 16, 51, -1, 64, -1, 68,  9, 48, 62, 54, 27, -1,  0,  0, -1,
                51, 15,  0, 80, 24, 25, 42, 54, 44, 71, 71,  9, 67, 35, -1, 58, -1, 29, -1, 53,  0, -1,  0,  0,
                16, 29, 36, 41, 44, 56, 59, 37, 50, 24, -1, 65,  4, 65, 52, -1,  4, -1, 73, 52,  1, -1, -1,  0};
// clang-format on

ldpc_t::ldpc_t(int nC)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] ldpc_t constructor entering" << endl;
#endif
    nCBs = nC;
    Z = 81;
    R = 5.0 / 6.0;
    k = 20;
    n = 24;
    for (int r = 0; r < n - k; r++)
        for (int c = 0; c < n; c++) H[r][c] = H5R6z81[r * n + c];
    K = k * Z;
    N = n * Z;
    for (int c = 0; c < n; c++)
    {
        for (int r = 0; r < n - k; r++)
        {
            mem[r][c] = new float[Z];
        }
        V[c] = new float[Z];
        C[c] = new float[Z];
        CmD[c] = new float[Z];
        E[c] = new float[Z];
        F[c] = new float[Z];
        G[c] = new float[Z];
    }

#ifdef DEBUG_PRINTF
    cout << "[INFO] ldpc_t constructor exiting" << endl;
#endif
}

ldpc_t::~ldpc_t(void)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] ldpc_t destructor entering" << endl;
#endif

    for (int c = 0; c < n; c++)
    {
        delete G[c];
        delete F[c];
        delete E[c];
        delete CmD[c];
        delete C[c];
        delete V[c];
        for (int r = 0; r < n - k; r++)
        {
            delete mem[r][c];
        }
    }

#ifdef DEBUG_PRINTF
    cout << "[INFO] ldpc_t destructor exiting" << endl;
#endif
}

void ldpc_t::run_rx(float *input, char *output, int *avgIter)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] ldpc_t run_rx entering" << endl;
#endif
#ifdef LDPC_PRINT_TIME
    auto start = std::chrono::high_resolution_clock::now();
#endif

    int sumIter = 0;
    for (int c = 0; c < nCBs; c++)
    {
        sumIter += decode(&input[c * N], &output[c * K]);
    }

    *avgIter = sumIter / nCBs;

#ifdef LDPC_PRINT_TIME
    auto stop = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> delta = stop - start;
    std::chrono::microseconds timeMicroSec = std::chrono::duration_cast<std::chrono::microseconds>(delta);
    std::cout << "[INFO] CPU ldpc run_rx execution time " << timeMicroSec.count() << "us\n";
#endif
#ifdef DEBUG_PRINTF
    cout << "[INFO] ldpc_t run_rx exiting" << endl;
#endif
}

int ldpc_t::decode(float *input, char *output)
{
    // initiate mems
    for (int c = 0; c < n; c++)
    {
        llr_copy(&input[c * Z], V[c]);
        for (int r = 0; r < n - k; r++)
        {
            if (H[r][c] != -1) llr_set(mem[r][c], 0.0);
        }
    }
    // iterate
    int i;
    for (i = 0; i < maxIt; i++)
    {
        for (int r = 0; r < n - k; r++)
        {
            for (int c = 0; c < n; c++)
            {
                if (H[r][c] != -1)
                {
                    // CNO operation
                    llr_rotate(V[c], C[c], -H[r][c]);
                    llr_sub(C[c], mem[r][c], CmD[c]);
                }
            }

            for (int c = 0; c < n; c++)
            {
                if (H[r][c] != -1)
                {
                    llr_set(E[c], LDPC_INFTY);
                    for (int cc = 0; cc < n; cc++)
                    {
                        if ((H[r][cc] != -1) && (c != cc))
                        {
                            llr_minsum(CmD[cc], E[c]);
                        }
                    }
                    llr_scale(E[c], kappa);
                }
            }


            for (int c = 0; c < n; c++)
            {
                // compute VNO and store new extrinsics in mem
                if (H[r][c] != -1)
                {
                    llr_sub(E[c], mem[r][c], F[c]);
                    llr_copy(E[c], mem[r][c]);
                    llr_add(F[c], C[c], G[c]);
                    llr_rotate(G[c], V[c], H[r][c]);
                }
            }
        }

        // syndrome weight computation
        bool syndromeError = false;
        for (int r = 0; r < n - k; r++)
        {
            llr_clear(S);
            int tmpWeight = 0;
            for (int c = 0; c < n; c++)
            {
                if (H[r][c] != -1) tmpWeight = llr_syndrome(V[c], S, -H[r][c]);
            }
            syndromeError |= (tmpWeight > 0);
        }

        if (syndromeError == false)
        {
            i = i + 1;
            break;
        }
    }

    // hard decoding
    for (int c = 0; c < k; c++) llr_hrd(V[c], &output[c * Z]);
    return i;
};

#define LIST_LEN 32

void ldpc_t::bit_print(char *input)
{
    printf("[DEBUG] bit[0:%d] = ", N - 1);
    for (int z = 0; z < N; z++)
    {
        if (z % Z == 0) printf("\n");
        printf("%d,", input[z]);
    }
    printf("\n");
}

void ldpc_t::llr_print(float *input)
{
    printf("[DEBUG] llr[0:%d] = ", Z - 1);
    for (int z = 0; z < LIST_LEN; z++) printf("%.4f,", input[z]);
    printf("...,");
    for (int z = Z - LIST_LEN; z < Z - 1; z++) printf("%.4f,", input[z]);
    printf("%.4f.\n", input[Z - 1]);
}

void ldpc_t::llr_hrd(float *input, char *output)
{
    for (int z = 0; z < Z; z++)
    {
        output[z] = input[z] < 0 ? 1 : 0;
    }
}

void ldpc_t::llr_copy(float *input, float *output)
{
    for (int z = 0; z < Z; z++)
    {
        output[z] = input[z];
    }
}

void ldpc_t::llr_set(float *output, float setValue)
{
    for (int z = 0; z < Z; z++)
    {
        output[z] = setValue;
    }
}

void ldpc_t::llr_scale(float *output, float scale)
{
    for (int z = 0; z < Z; z++)
    {
        output[z] *= scale;
    }
}


void ldpc_t::llr_rotate(float *input, float *output, int shift)
{
    for (int z = 0; z < Z; z++)
    {
        output[z] = input[(z - shift + Z) % Z];
    }
};

int ldpc_t::llr_syndrome(float *input, bool *output, int shift)
{
    int weight = 0;
    for (int z = 0; z < Z; z++)
    {
        bool bit0 = input[(z - shift + Z) % Z] < 0.0;
        bool bit1 = output[z];
        weight = bit0 ^ bit1 ? weight + 1 : weight;
        output[z] = bit0 ^ bit1 ? true : false;
    }
    return weight;
};

void ldpc_t::llr_clear(bool *output)
{
    for (int z = 0; z < Z; z++)
    {
        output[z] = false;
    }
};

void ldpc_t::llr_sub(float *input1, float *input2, float *output)
{
    for (int z = 0; z < Z; z++)
    {
        output[z] = input1[z] - input2[z];
    }
};

void ldpc_t::llr_add(float *input1, float *input2, float *output)
{
    for (int z = 0; z < Z; z++)
    {
        output[z] = input1[z] + input2[z];
    }
};

void ldpc_t::llr_minsum(float *input, float *output)
{
    for (int z = 0; z < Z; z++)
    {
        bool inpNeg = input[z] < 0;
        bool outNeg = output[z] < 0;
        float inpAbs = inpNeg ? -input[z] : input[z];
        float outAbs = outNeg ? -output[z] : output[z];

        if (inpAbs < outAbs)
        {
            output[z] = outNeg ? -input[z] : input[z];
        }
        else
        {
            output[z] = inpNeg ? -output[z] : output[z];
        }
    }
};


void ldpc_t::print(char *output)
{
    printf("[DEBUG] ldpc config k = %d, n = %d, Z = %d, max iter%d\n", k, n, Z, maxIt);
    for (int c = 0; c < nCBs; c++)
    {
        printf("[DEBUG] ldpc_info[%d][0:%d] = ", c, K - 1);
        for (int m = 0; m < LIST_LEN; m++) printf("%d,", output[c * K + m]);
        printf(",..........,");
        for (int m = K - LIST_LEN; m < K - 1; m++) printf("%d,", output[c * K + m]);
        printf("%d.\n", output[c * K + K - 1]);
    }
};
