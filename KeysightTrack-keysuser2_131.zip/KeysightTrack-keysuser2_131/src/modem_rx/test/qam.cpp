#include "qam.hpp"
#include <cmath>
#include <ctime>
#include <chrono>

using namespace hostQam;
using namespace std;

qam_t::qam_t(const_t qamType, int nElements)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] qam_t constructor entering" << endl;
#endif

    Q = qamType;
    nRe = nElements;
    int b[5];
    switch (Q)
    {
        case BPSK:
            for (int i = 0; i < 2; i++)
            {
                P[i] = (1 / sqrt(2.0)) * (1 - 2 * i);
            }
            break;

        case QPSK:
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 1; j++) b[j] = (i >> j) & 1;
                P[i] = (1 / sqrt(2)) * (1 - 2 * b[0]);
            }
            break;

        case QAM16:
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 2; j++) b[j] = (i >> j) & 1;
                P[i] = (1 / sqrt(10)) * (1 - 2 * b[0]) * (2 - (1 - 2 * b[1]));
            }
            break;

        case QAM64:
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 3; j++) b[j] = (i >> j) & 1;
                P[i] = (1 / sqrt(42)) * (1 - 2 * b[0]) * (4 - (1 - 2 * b[1]) * (2 - (1 - 2 * b[2])));
            }
            break;
        case QAM256:
            for (int i = 0; i < 16; i++)
            {
                for (int j = 0; j < 4; j++) b[j] = (i >> j) & 1;
                P[i] = (1 / sqrt(170)) * (1 - 2 * b[0])
                     * (8 - (1 - 2 * b[1]) * (4 - (1 - 2 * b[2]) * (2 - (1 - 2 * b[3]))));
            }
            break;
        case QAM1024:
            for (int i = 0; i < 32; i++)
            {
                for (int j = 0; j < 5; j++) b[j] = (i >> j) & 1;
                P[i] = (1 / sqrt(682)) * (1 - 2 * b[0])
                     * (16 - (1 - 2 * b[1]) * (8 - (1 - 2 * b[2]) * (4 - (1 - 2 * b[3]) * (2 - (1 - 2 * b[4])))));
            }
            break;
    }

#ifdef DEBUG_PRINTF
    cout << "[INFO] qam_t constructor exiting" << endl;
#endif
}

qam_t::~qam_t(void)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] qam_t destructor entering" << endl;
#endif
#ifdef DEBUG_PRINTF
    cout << "[INFO] qam_t destructor exiting" << endl;
#endif
}

// debug utility
void qam_t::print(float *output)
{
    printf("[DEBUG] qam config nRe = %d, Q = %d\n", nRe, Q);
#define LIST_LEN 8
    for (int n = 0; n < LIST_LEN; n++)
    {
        printf("[DEBUG] qam_output[%d][0:%d] = ", n, Q - 1);
        for (int k = 0; k < Q - 1; k++) printf("%.4f,", output[n * Q + k]);
        printf("%.4f.\n", output[n * Q + Q - 1]);
    }
    printf("[DEBUG] ......\n");
    for (int n = nRe - LIST_LEN; n < nRe; n++)
    {
        printf("[DEBUG] qam_output[%d][0:%d] = ", n, Q - 1);
        for (int k = 0; k < Q - 1; k++) printf("%.4f,", output[n * Q + k]);
        printf("%.4f.\n", output[n * Q + Q - 1]);
    }
}

void qam_t::run_rxqam1024(complex_t *input, float *output)
{
    for (int n = 0; n < nRe; n++)
    {
        complex_t u = input[n];

        float d0_re[10] = {INFTY, INFTY, INFTY, INFTY, INFTY, INFTY, INFTY, INFTY, INFTY, INFTY};
        float d0_im[10] = {INFTY, INFTY, INFTY, INFTY, INFTY, INFTY, INFTY, INFTY, INFTY, INFTY};
        float d1_re[10] = {INFTY, INFTY, INFTY, INFTY, INFTY, INFTY, INFTY, INFTY, INFTY, INFTY};
        float d1_im[10] = {INFTY, INFTY, INFTY, INFTY, INFTY, INFTY, INFTY, INFTY, INFTY, INFTY};

        for (int k = 0; k < 32; k++)
        {
            int b0 = (k & 1);
            int b1 = (k & 2) >> 1;
            int b2 = (k & 4) >> 2;
            int b3 = (k & 8) >> 3;
            int b4 = (k & 16) >> 4;

            float pnt = P[k];

            float d_re = (u.real - pnt);
            float d_im = (u.imag - pnt);
            d_re *= d_re;
            d_im *= d_im;

            if (b0 == 0)
            {
                // bit 0,1
                d0_re[0] = (d0_re[0] < d_re) ? d0_re[0] : d_re;
                d0_im[1] = (d0_im[1] < d_im) ? d0_im[1] : d_im;
            }
            else
            {
                // bit 0,1
                d1_re[0] = (d1_re[0] < d_re) ? d1_re[0] : d_re;
                d1_im[1] = (d1_im[1] < d_im) ? d1_im[1] : d_im;
            }

            if (b1 == 0)
            {
                // bit 2,3
                d0_re[2] = (d0_re[2] < d_re) ? d0_re[2] : d_re;
                d0_im[3] = (d0_im[3] < d_im) ? d0_im[3] : d_im;
            }
            else
            {
                // bit 2,3
                d1_re[2] = (d1_re[2] < d_re) ? d1_re[2] : d_re;
                d1_im[3] = (d1_im[3] < d_im) ? d1_im[3] : d_im;
            }

            if (b2 == 0)
            {
                // bit 4,5
                d0_re[4] = (d0_re[4] < d_re) ? d0_re[4] : d_re;
                d0_im[5] = (d0_im[5] < d_im) ? d0_im[5] : d_im;
            }
            else
            {
                // bit 4,5
                d1_re[4] = (d1_re[4] < d_re) ? d1_re[4] : d_re;
                d1_im[5] = (d1_im[5] < d_im) ? d1_im[5] : d_im;
            }

            if (b3 == 0)
            {
                // bit 6,7
                d0_re[6] = (d0_re[6] < d_re) ? d0_re[6] : d_re;
                d0_im[7] = (d0_im[7] < d_im) ? d0_im[7] : d_im;
            }
            else
            {
                // bit 6,7
                d1_re[6] = (d1_re[6] < d_re) ? d1_re[6] : d_re;
                d1_im[7] = (d1_im[7] < d_im) ? d1_im[7] : d_im;
            }

            if (b4 == 0)
            {
                // bit 8,9
                d0_re[8] = (d0_re[8] < d_re) ? d0_re[8] : d_re;
                d0_im[9] = (d0_im[9] < d_im) ? d0_im[9] : d_im;
            }
            else
            {
                // bit 8,9
                d1_re[8] = (d1_re[8] < d_re) ? d1_re[8] : d_re;
                d1_im[9] = (d1_im[9] < d_im) ? d1_im[9] : d_im;
            }
        }
        for (int k = 0; k < 10; k++) output[n * 10 + k] = d1_re[k] + d1_im[k] - d0_re[k] - d0_im[k];
    }
}

void qam_t::run_rxqam256(complex_t *input, float *output)
{
    for (int n = 0; n < nRe; n++)
    {
        complex_t u = input[n];

        float d0_re[8] = {INFTY, INFTY, INFTY, INFTY, INFTY, INFTY, INFTY, INFTY};
        float d0_im[8] = {INFTY, INFTY, INFTY, INFTY, INFTY, INFTY, INFTY, INFTY};
        float d1_re[8] = {INFTY, INFTY, INFTY, INFTY, INFTY, INFTY, INFTY, INFTY};
        float d1_im[8] = {INFTY, INFTY, INFTY, INFTY, INFTY, INFTY, INFTY, INFTY};

        for (int k = 0; k < 16; k++)
        {
            int b0 = (k & 1);
            int b1 = (k & 2) >> 1;
            int b2 = (k & 4) >> 2;
            int b3 = (k & 8) >> 3;

            float pnt = P[k];

            float d_re = (u.real - pnt);
            float d_im = (u.imag - pnt);
            d_re *= d_re;
            d_im *= d_im;

            if (b0 == 0)
            {
                // bit 0,1
                d0_re[0] = (d0_re[0] < d_re) ? d0_re[0] : d_re;
                d0_im[1] = (d0_im[1] < d_im) ? d0_im[1] : d_im;
            }
            else
            {
                // bit 0,1
                d1_re[0] = (d1_re[0] < d_re) ? d1_re[0] : d_re;
                d1_im[1] = (d1_im[1] < d_im) ? d1_im[1] : d_im;
            }

            if (b1 == 0)
            {
                // bit 2,3
                d0_re[2] = (d0_re[2] < d_re) ? d0_re[2] : d_re;
                d0_im[3] = (d0_im[3] < d_im) ? d0_im[3] : d_im;
            }
            else
            {
                // bit 2,3
                d1_re[2] = (d1_re[2] < d_re) ? d1_re[2] : d_re;
                d1_im[3] = (d1_im[3] < d_im) ? d1_im[3] : d_im;
            }

            if (b2 == 0)
            {
                // bit 4,5
                d0_re[4] = (d0_re[4] < d_re) ? d0_re[4] : d_re;
                d0_im[5] = (d0_im[5] < d_im) ? d0_im[5] : d_im;
            }
            else
            {
                // bit 4,5
                d1_re[4] = (d1_re[4] < d_re) ? d1_re[4] : d_re;
                d1_im[5] = (d1_im[5] < d_im) ? d1_im[5] : d_im;
            }

            if (b3 == 0)
            {
                // bit 6,7
                d0_re[6] = (d0_re[6] < d_re) ? d0_re[6] : d_re;
                d0_im[7] = (d0_im[7] < d_im) ? d0_im[7] : d_im;
            }
            else
            {
                // bit 6,7
                d1_re[6] = (d1_re[6] < d_re) ? d1_re[6] : d_re;
                d1_im[7] = (d1_im[7] < d_im) ? d1_im[7] : d_im;
            }
        }
        for (int k = 0; k < 8; k++) output[n * 8 + k] = d1_re[k] + d1_im[k] - d0_re[k] - d0_im[k];
    }
}

void qam_t::run_rxqam64(complex_t *input, float *output)
{
    for (int n = 0; n < nRe; n++)
    {
        complex_t u = input[n];

        float d0_re[6] = {INFTY, INFTY, INFTY, INFTY, INFTY, INFTY};
        float d0_im[6] = {INFTY, INFTY, INFTY, INFTY, INFTY, INFTY};
        float d1_re[6] = {INFTY, INFTY, INFTY, INFTY, INFTY, INFTY};
        float d1_im[6] = {INFTY, INFTY, INFTY, INFTY, INFTY, INFTY};

        for (int k = 0; k < 8; k++)
        {
            int b0 = (k & 1);
            int b1 = (k & 2) >> 1;
            int b2 = (k & 4) >> 2;

            float pnt = P[k];

            float d_re = (u.real - pnt);
            float d_im = (u.imag - pnt);
            d_re *= d_re;
            d_im *= d_im;

            if (b0 == 0)
            {
                // bit 0,1
                d0_re[0] = (d0_re[0] < d_re) ? d0_re[0] : d_re;
                d0_im[1] = (d0_im[1] < d_im) ? d0_im[1] : d_im;
            }
            else
            {
                // bit 0,1
                d1_re[0] = (d1_re[0] < d_re) ? d1_re[0] : d_re;
                d1_im[1] = (d1_im[1] < d_im) ? d1_im[1] : d_im;
            }

            if (b1 == 0)
            {
                // bit 2,3
                d0_re[2] = (d0_re[2] < d_re) ? d0_re[2] : d_re;
                d0_im[3] = (d0_im[3] < d_im) ? d0_im[3] : d_im;
            }
            else
            {
                // bit 2,3
                d1_re[2] = (d1_re[2] < d_re) ? d1_re[2] : d_re;
                d1_im[3] = (d1_im[3] < d_im) ? d1_im[3] : d_im;
            }

            if (b2 == 0)
            {
                // bit 4,5
                d0_re[4] = (d0_re[4] < d_re) ? d0_re[4] : d_re;
                d0_im[5] = (d0_im[5] < d_im) ? d0_im[5] : d_im;
            }
            else
            {
                // bit 4,5
                d1_re[4] = (d1_re[4] < d_re) ? d1_re[4] : d_re;
                d1_im[5] = (d1_im[5] < d_im) ? d1_im[5] : d_im;
            }
        }
        for (int k = 0; k < 6; k++) output[n * 6 + k] = d1_re[k] + d1_im[k] - d0_re[k] - d0_im[k];
    }
}

void qam_t::run_rxqam16(complex_t *input, float *output)
{
    for (int n = 0; n < nRe; n++)
    {
        complex_t u = input[n];

        float d0_re[4] = {INFTY, INFTY, INFTY, INFTY};
        float d0_im[4] = {INFTY, INFTY, INFTY, INFTY};
        float d1_re[4] = {INFTY, INFTY, INFTY, INFTY};
        float d1_im[4] = {INFTY, INFTY, INFTY, INFTY};

        for (int k = 0; k < 4; k++)
        {
            int b0 = (k & 1);
            int b1 = (k & 2) >> 1;

            float pnt = P[k];

            float d_re = (u.real - pnt);
            float d_im = (u.imag - pnt);
            d_re *= d_re;
            d_im *= d_im;

            if (b0 == 0)
            {
                // bit 0,1
                d0_re[0] = (d0_re[0] < d_re) ? d0_re[0] : d_re;
                d0_im[1] = (d0_im[1] < d_im) ? d0_im[1] : d_im;
            }
            else
            {
                // bit 0,1
                d1_re[0] = (d1_re[0] < d_re) ? d1_re[0] : d_re;
                d1_im[1] = (d1_im[1] < d_im) ? d1_im[1] : d_im;
            }

            if (b1 == 0)
            {
                // bit 2,3
                d0_re[2] = (d0_re[2] < d_re) ? d0_re[2] : d_re;
                d0_im[3] = (d0_im[3] < d_im) ? d0_im[3] : d_im;
            }
            else
            {
                // bit 2,3
                d1_re[2] = (d1_re[2] < d_re) ? d1_re[2] : d_re;
                d1_im[3] = (d1_im[3] < d_im) ? d1_im[3] : d_im;
            }
        }
        for (int k = 0; k < 4; k++) output[n * 4 + k] = d1_re[k] + d1_im[k] - d0_re[k] - d0_im[k];
    }
}

void qam_t::run_rxqam4(complex_t *input, float *output)
{
    for (int n = 0; n < nRe; n++)
    {
        complex_t u = input[n];

        float d0_re[2] = {INFTY, INFTY};
        float d0_im[2] = {INFTY, INFTY};
        float d1_re[2] = {INFTY, INFTY};
        float d1_im[2] = {INFTY, INFTY};

        for (int k = 0; k < 2; k++)
        {
            float pnt = P[k];
            float d_re = (u.real - pnt);
            float d_im = (u.imag - pnt);
            d_re *= d_re;
            d_im *= d_im;

            if (k == 0)
            {
                // bit 0,1
                d0_re[0] = (d0_re[0] < d_re) ? d0_re[0] : d_re;
                d0_im[1] = (d0_im[1] < d_im) ? d0_im[1] : d_im;
            }
            else
            {
                // bit 0,1
                d1_re[0] = (d1_re[0] < d_re) ? d1_re[0] : d_re;
                d1_im[1] = (d1_im[1] < d_im) ? d1_im[1] : d_im;
            }
        }
        for (int k = 0; k < 2; k++) output[n * 2 + k] = d1_re[k] + d1_im[k] - d0_re[k] - d0_im[k];
    }
}

void qam_t::run_rxqam2(complex_t *input, float *output)
{
    for (int n = 0; n < nRe; n++)
    {
        complex_t u = input[n];

        float pnt = P[0];
        float d_re = u.real - pnt;
        float d_im = u.imag - pnt;
        float d0 = d_re * d_re + d_im * d_im;

        pnt = P[1];
        d_re = u.real - pnt;
        d_im = u.imag - pnt;
        float d1 = d_re * d_re + d_im * d_im;

        output[n] = d1 - d0;
    }
}


void qam_t::run_rx(complex_t *input, float *output)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] qam_t run_rx entering" << endl;
#endif
#ifdef QAM_PRINT_TIME
    auto start = std::chrono::high_resolution_clock::now();
#endif

    switch (Q)
    {
        case BPSK:
            run_rxqam2(input, output);
            break;
        case QPSK:
            run_rxqam4(input, output);
            break;
        case QAM16:
            run_rxqam16(input, output);
            break;
        case QAM64:
            run_rxqam64(input, output);
            break;
        case QAM256:
            run_rxqam256(input, output);
            break;
        default:
            run_rxqam1024(input, output);
            break;
    }
#ifdef QAM_PRINT_TIME
    auto stop = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> delta = stop - start;
    std::chrono::microseconds timeMicroSec = std::chrono::duration_cast<std::chrono::microseconds>(delta);
    std::cout << "[INFO] CPU qam run_rx execution time " << timeMicroSec.count() << "us\n";
#endif
#ifdef DEBUG_PRINTF
    cout << "[INFO] qam_t run_rx exiting" << endl;
#endif
}