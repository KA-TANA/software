#include "equ.hpp"
#include <ctime>
#include <chrono>

using namespace hostEqu;
using namespace std;

equ_t::equ_t(int fftSize, int nSymbols, bool *freqMask, bool *dmrsMask, bool *pdchMask)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] equ_t constructor entering" << endl;
#endif

    nFFT = fftSize;
    nSym = nSymbols;
    FreqMask = freqMask;
    DmrsMask = dmrsMask;
    PdchMask = pdchMask;
    dmrs_output = new complex_t[fftSize * nSymbols];
    // setup DMRS object
    dmrs = new dmrs_t(fftSize, nSymbols, freqMask, dmrsMask);
    Hinv = new complex_t[fftSize * nSymbols];
    hinv = new complex_t[fftSize];

#ifdef DEBUG_PRINTF
    cout << "[INFO] equ_t constructor exiting" << endl;
#endif
}

equ_t::~equ_t(void)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] equ_t destructor entering" << endl;
#endif

    delete[] hinv;
    delete[] Hinv;
    delete[] dmrs_output;
    delete dmrs;

#ifdef DEBUG_PRINTF
    cout << "[INFO] equ_t destructor exiting" << endl;
#endif
}

void equ_t::run_est(complex_t *input)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] equ_t run_est entering" << endl;
#endif
#ifdef EQU_PRINT_TIME
    auto start = std::chrono::high_resolution_clock::now();
#endif

    dmrs->run(dmrs_output);

    // generate inverse channel over RE's containing dmrs
    for (int k = 0; k < nFFT; k++)
    {
        hinv[k].real = 0.0;
        hinv[k].imag = 0.0;
    }
    for (int n = 0; n < nSym; n++)
    {
        for (int k = 0; k < nFFT; k++)
        {
            complex_t x, y, h;
            if (DmrsMask[n] && FreqMask[k])
            {
                x = input[n * nFFT + k];
                y = dmrs_output[n * nFFT + k];
                h = (y * x.conj()) / (x.abs2());
                hinv[k] = h;
            }
            Hinv[n * nFFT + k] = hinv[k];
        }
    }

#ifdef EQU_PRINT_TIME
    auto stop = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> delta = stop - start;
    std::chrono::microseconds timeMicroSec = std::chrono::duration_cast<std::chrono::microseconds>(delta);
    std::cout << "[INFO] CPU equ run_est execution time " << timeMicroSec.count() << "us\n";
#endif
#ifdef DEBUG_PRINTF
    cout << "[INFO] equ_t run_est exiting" << endl;
#endif
};

void equ_t::run(complex_t *input, complex_t *output)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] equ_t run entering" << endl;
#endif
#ifdef EQU_PRINT_TIME
    auto start = std::chrono::high_resolution_clock::now();
#endif

    for (int n = 0; n < nSym; n++)
    {
        for (int k = 0; k < nFFT; k++)
        {
            output[n * nFFT + k] = PdchMask[n] ? input[n * nFFT + k] * Hinv[n * nFFT + k] : input[n * nFFT + k];
        }
    }

#ifdef EQU_PRINT_TIME
    auto stop = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> delta = stop - start;
    std::chrono::microseconds timeMicroSec = std::chrono::duration_cast<std::chrono::microseconds>(delta);
    std::cout << "[INFO] CPU equ run execution time " << timeMicroSec.count() << "us\n";
#endif
#ifdef DEBUG_PRINTF
    cout << "[INFO] equ_t run exiting" << endl;
#endif
};
