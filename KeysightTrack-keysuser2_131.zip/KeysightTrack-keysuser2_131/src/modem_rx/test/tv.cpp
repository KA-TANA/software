#include "tv.hpp"

using namespace std;

bool tv_t::read_modem_iq_file(complex_t *rx_iq, int nElem, char *fname)
{
    // fetch IQ from TV
    ifstream fid;
    fid.open(fname);
    if (!fid)
    {
        cout << "[ERROR] " << fname << " not found" << endl;
        return ERROR;
    }
    int n = 0;
    while (!fid.eof())
    {
        char ch;
        fid >> rx_iq[0].real >> ch >> rx_iq[0].imag;
        rx_iq++;
        n++;
        if (n == nElem) break;
    }
    fid.close();
    if (n < nElem)
    {
        cout << "[ERROR] " << fname << " is incomplete" << endl;
        return ERROR;
    }
    return !ERROR;
}

bool tv_t::read_modem_data_file(char *rx_data, int nElem, char *fname)
{
    // fetch IQ from TV
    ifstream fid;
    fid.open(fname);
    if (!fid)
    {
        cout << "[ERROR] " << fname << " not found" << endl;
        return ERROR;
    }
    int n = 0;
    while (!fid.eof())
    {
        unsigned int data;
        fid >> data;
        *rx_data++ = (char)data;
        n++;
        if (n == nElem) break;
    }
    fid.close();
    if (n < nElem)
    {
        cout << "[ERROR] " << fname << " is incomplete" << endl;
        return ERROR;
    }
    return !ERROR;
}

bool tv_t::check_modem_rx_data(char **fname)
{
    if (ShouldBeCRCError) return !ERROR;
    // fetch paylad from TV
    char *modem_data = new char[TrBlkSize];
    if (read_modem_data_file(modem_data, TrBlkSize, fname[3]) == ERROR) exit(1);


    // compare
    int error_cnt = 0;
    for (int n = 0; n < TrBlkSize; n++)
    {
        if (rx_payload[n] != modem_data[n])
        {
            if (error_cnt++ < 16) printf("[ERROR] rx_data[%d] = %d <> %d\n", n, rx_payload[n], modem_data[n]);
        }
    }
    delete[] modem_data;

    if (error_cnt == 0)
        return !ERROR;
    else
        return ERROR;
}

tv_t::tv_t(char **fname)
{
    ifstream fid;
    fid.open(fname[1]);
    if (!fid)
    {
        cout << "[ERROR] " << fname[1] << " not found" << endl;
        exit(1);
    }

    fid >> slotTime;
    fid >> QamSize;
    fid >> nFFT;
    fid >> nPrb;
    fid >> nSym;

    cpSizes = new int[nSym];
    for (int n = 0; n < nSym; n++)
    {
        fid >> cpSizes[n];
    }

    PdchMask = new bool[nSym];
    for (int n = 0; n < nSym; n++)
    {
        fid >> PdchMask[n];
    }


    DmrsMask = new bool[nSym];
    for (int n = 0; n < nSym; n++)
    {
        fid >> DmrsMask[n];
    }

    fid >> TrBlkSize;
    FreqMask = new bool[nFFT];
    for (int n = 0; n < nFFT; n++)
    {
        fid >> FreqMask[n];
    }
    fid >> ShouldBeCRCError;

    fid >> cfo;
    //-------------------------
    // compute slot size in samples and read from IQ file
    //
    int slotSize = 0;
    for (int n = 0; n < nSym; n++) slotSize += cpSizes[n] + nFFT;
    // fetch IQ from TV
    rx_iq = new complex_t[slotSize];

    float Fs = (float)slotSize / slotTime;

    cout << endl << endl;
    cout << "[INFO] ========================================================================================\n";
    cout << "[INFO] | Modem Rx \n";
    cout << "[INFO] | Test cnf  vector : " << fname[1] << endl;
    cout << "[INFO] | Test iq   vector : " << fname[2] << endl;
    cout << "[INFO] | Test tbs  vector : " << fname[3] << endl;

    printf(
        "[INFO] | SlotTime = %.2e s, nFFT = %4d, nPrb = %3d, nSym = %2d, TrBlkSize = %6d, QamSize = %2d, cfo = %.1f Hz\n",
        slotTime,
        nFFT,
        nPrb,
        nSym,
        TrBlkSize,
        QamSize,
        cfo * Fs);

    printf("[INFO] | cpSizes[0:%d] = {", nSym - 1);
    for (int n = 0; n < nSym; n++) printf("%3d ", cpSizes[n]);
    printf("}\n");
    printf("[INFO] | PdchMask[0:%d] = {", nSym - 1);
    for (int n = 0; n < nSym; n++) printf("%1d ", PdchMask[n]);
    printf("}\n");
    printf("[INFO] | DmrsMask[0:%d] = {", nSym - 1);
    for (int n = 0; n < nSym; n++) printf("%1d ", DmrsMask[n]);
    printf("}\n");

    float tPut = (TrBlkSize * 8.0) / slotTime;
    printf("[INFO] | Tput %.2f Mbps\n", tPut / 1.0e6);

    float PdchNumSym = 0.0;
    for (int n = 0; n < nSym; n++) PdchNumSym = PdchMask[n] ? (PdchNumSym + 1.0) : PdchNumSym;
    float nRe = 0.0;
    for (int n = 0; n < nFFT; n++) nRe = FreqMask[n] ? (nRe + 1.0) : nRe;
    float Cr = (TrBlkSize * 8.0) / (nRe * PdchNumSym * QamSize);
    printf("[INFO] | CodingRate %.2f Mbps\n", Cr);
    printf("[INFO] ========================================================================================\n\n\n");

    if (read_modem_iq_file(rx_iq, slotSize, fname[2]) == ERROR) exit(1);

    rx_payload = new char[TrBlkSize];


    fid.close();
}

tv_t::~tv_t()
{
    delete FreqMask;
    delete rx_iq;
    delete rx_payload;
}
