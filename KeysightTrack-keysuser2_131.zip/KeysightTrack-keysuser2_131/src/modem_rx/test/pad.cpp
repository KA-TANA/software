#include "pad.hpp"
#include <ctime>
#include <chrono>

using namespace hostPad;
using namespace std;

pad_t::pad_t(int C, int B, int K)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] pad_t constructor entering" << endl;
#endif

    int F = C * K - B; // total number of filler bits
    F0 = (F + C - 1) / C;
    c0 = F % C;
    K0 = K - F0;

    F1 = F / C;
    c1 = C - c0;
    K1 = K - F1;

#ifdef DEBUG_PRINTF
    cout << "[INFO] pad_t constructor exiting" << endl;
#endif
}

pad_t::~pad_t(void)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] pad_t destructor entering" << endl;
    cout << "[INFO] pad_t destructor exiting" << endl;
#endif
}

void pad_t::run_rx(char *input, char *output)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] pad_t run_rx entering" << endl;
#endif
#ifdef PAD_PRINT_TIME
    auto start = std::chrono::high_resolution_clock::now();
#endif

    for (int c = 0; c < c0; c++)
    {
        for (int n = 0; n < K0; n++)
        {
            output[0] = input[0];
            output++;
            input++;
        }
        input += F0;
    }
    for (int c = 0; c < c1; c++)
    {
        for (int n = 0; n < K1; n++)
        {
            output[0] = input[0];
            output++;
            input++;
        }
        input += F1;
    }

#ifdef PAD_PRINT_TIME
    auto stop = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> delta = stop - start;
    std::chrono::microseconds timeMicroSec = std::chrono::duration_cast<std::chrono::microseconds>(delta);
    std::cout << "[INFO] CPU pad run_rx execution time " << timeMicroSec.count() << "us\n";
#endif
#ifdef DEBUG_PRINTF
    cout << "[INFO] pad_t run_rx exiting" << endl;
#endif
};

void pad_t::print(char *input)
{
    printf("[DEBUG] pad config c0 = %d, K0 = %d, F0 =%d c1 = %d, K1 = %d, F1 = %d\n", c0, K0, F0, c1, K1, F1);
#define LIST_LEN 16
    printf("[DEBUG] pad_output[0:%d] = ", c0 * K0 + c1 * K1 - 1);
    for (int n = 0; n < LIST_LEN; n++) printf("%d,", input[n]);
    printf(",..........,");
    for (int n = c0 * K0 + c1 * K1 - LIST_LEN; n < c0 * K0 + c1 * K1 - 1; n++) printf("%d,", input[n]);
    printf("%d.\n", input[c0 * K0 + c1 * K1 - 1]);
};
