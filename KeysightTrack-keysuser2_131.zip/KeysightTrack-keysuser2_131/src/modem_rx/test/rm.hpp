#pragma once
#include <iostream>
#include "mtypes.hpp"
//#include "qam.hpp"
#include "cudaQam.cuh"

#ifdef PRINT_EXECUTION_TIMES
#define RM_PRINT_TIME
#endif

using namespace cudaQam;

namespace hostRm
{

class rm_t
{
public:
    int E0;
    int E1;
    int g0;
    int g1;
    int N;
    // constructor
    rm_t() = delete;
    rm_t(int G, int C, int codeBlockLength, const_t qamType);

    // destructor
    virtual ~rm_t();

    void run_rx(float *input, float *output);
    void print(float *output);
};

}
