#pragma once
#include <iostream>
#include <fstream>
#include "mtypes.hpp"

#define ERROR true
class tv_t
{
public:
    int QamSize;
    float slotTime;
    int nFFT;
    int nPrb;
    int nSym;
    int *cpSizes;
    bool *PdchMask;
    bool *DmrsMask;
    int TrBlkSize;
    bool *FreqMask;
    float cfo;
    complex_t *rx_iq;
    char *rx_payload;
    bool ShouldBeCRCError;
    // constructor
    tv_t(char **fname);

    // destructor
    virtual ~tv_t();

    bool check_modem_rx_data(char **fname);


private:
    bool read_modem_iq_file(complex_t *rx_iq, int nElem, char *fname);
    bool read_modem_data_file(char *rx_data, int nElem, char *fname);
};
