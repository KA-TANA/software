#pragma once
#include "mtypes.hpp"

#include "cudaCrc.cuh"
#include "cudaLdpc.cuh"
#include "crc.hpp"
#include "ldpc.hpp"

#include "pad.hpp"
#include "rm.hpp"
#include "inter.hpp"
#include "qam.hpp"
#include "cudaQam.cuh"
#include "map.hpp"

#ifdef PRINT_EXECUTION_TIMES
#define PDCH_PRINT_TIME
#endif

namespace hostPdch
{


using namespace hostCrc;
using namespace hostLdpc;
//using namespace cudaCrc;
//using namespace cudaLdpc;

using namespace hostInter;
//using namespace hostQam;
using namespace cudaQam;
using namespace hostPad;
using namespace hostRm;
using namespace hostMap;

class pdch_t
{
public:
    int nFFT;       // cell BW,  DFT size
    int nSym;       //
    bool *FreqMask; // channel allocation mask in frequency for data
    bool *TimeMask; // DMRS position mask
    int nRe;        //
    int G;
    int C;
    int A;
    int CodeBlockLength;
    complex_t *map_output;
    float *qam_output;
    float *inter_output;
    float *rm_output;
    char *ldpc_output;
    char *cuda_ldpc_output;
    char *pad_output;
    const_t QamType;
    crc_t *crc;

    ldpc_t *ldpc;
    pad_t *pad;
    rm_t *rm;
    inter_t *inter;
    qam_t *qam;
    map_t *map;

    // constructor
    pdch_t() = delete;
    pdch_t(int FFTSize, int nSymbol, bool *freqMask, bool *pdchMask, const_t qamSize, int trBlkSize);

    // destructor
    virtual ~pdch_t();

    void run_rx(complex_t *input, char *output, bool *crcStatus, int *iterations);

private:
    void bit2byte(char *input, char *output);
    void print(char *input);
};

}
