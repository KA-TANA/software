#pragma once
#include <iostream>
#include <fstream>

//#define DEBUG_PRINT
#define PRINT_EXECUTION_TIMES

class complex_t
{
public:
    float real;
    float imag;
    complex_t operator+(complex_t const &obj)
    {
        complex_t res;
        res.real = real + obj.real;
        res.imag = imag + obj.imag;
        return res;
    }

    complex_t operator-(complex_t const &obj)
    {
        complex_t res;
        res.real = real - obj.real;
        res.imag = imag - obj.imag;
        return res;
    }

    complex_t operator*(complex_t const &obj)
    {
        complex_t res;
        res.real = real * obj.real - imag * obj.imag;
        res.imag = real * obj.imag + imag * obj.real;
        return res;
    }
    complex_t conj(void)
    {
        complex_t res;
        res.real = real;
        res.imag = -imag;
        return res;
    }
    float abs2(void)
    {
        float res = real * real + imag * imag;
        return res;
    }
    complex_t operator/(float const &x)
    {
        complex_t res;
        res.real = real / x;
        res.imag = imag / x;
        return res;
    }
    complex_t operator*(float const &x)
    {
        complex_t res;
        res.real = real * x;
        res.imag = imag * x;
        return res;
    }
};
