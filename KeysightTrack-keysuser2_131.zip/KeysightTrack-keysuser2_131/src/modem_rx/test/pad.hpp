#pragma once
#include <iostream>
#include "mtypes.hpp"

#ifdef PRINT_EXECUTION_TIMES
#define PAD_PRINT_TIME
#endif

namespace hostPad
{

class pad_t
{
public:
    int c0;
    int c1;
    int K0;
    int K1;
    int F0;
    int F1;

    // constructor
    pad_t() = delete;
    pad_t(int nCodeBlocks, int nBits, int nSysBits);

    // destructor
    virtual ~pad_t();

    void run_rx(char *input, char *output);
    void print(char *input);
};

}
