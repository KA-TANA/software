#include "cexp.hpp"
#include <cmath>
#include <ctime>
#include <chrono>

using namespace hostCexp;
using namespace std;

cexp_t::cexp_t(int FFTSize, int nSymbol, int *CpSizes)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] cexp_t constructor entering" << endl;
#endif
    slotSize = 0;
    marginCp = CpSizes[0];
    maxSto = 0;
    for (int n = 1; n < nSymbol; n++)
    {
        maxSto = maxSto > CpSizes[n] ? maxSto : CpSizes[n];
    }

    for (int n = 0; n < nSymbol; n++)
    {
        slotSize += FFTSize + CpSizes[n];
        marginCp = marginCp < CpSizes[n] / 2 ? marginCp : CpSizes[n] / 2;
    }
    nSym = nSymbol;
    cpSizes = CpSizes;
    nFFT = FFTSize;
    cfo = 0.0;
    sto = 0.0;
    xCorr = new complex_t[maxSto + 1];

#ifdef DEBUG_PRINTF
    cout << "[INFO] cexp_t constructor exiting" << endl;
#endif
}

cexp_t::~cexp_t(void)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] cexp_t destructor entering" << endl;
    delete xCorr;
    cout << "[INFO] cexp_t destructor exiting" << endl;
#endif
}

void cexp_t::run_rx(complex_t *input, complex_t *output)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] cexp_t run_rx  entering" << endl;
#endif

#ifdef CEXP_PRINT_TIME
    auto start = std::chrono::high_resolution_clock::now();
#endif

    for (int n = 0; n < slotSize; n++)
    {
        float phase = -2 * PI * cfo * n;
        complex_t rot;
        rot.real = cos(phase);
        rot.imag = sin(phase);
        output[n] = input[n] * rot;
    }

#ifdef CEXP_PRINT_TIME
    auto stop = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> delta = stop - start;
    std::chrono::microseconds timeMicroSec = std::chrono::duration_cast<std::chrono::microseconds>(delta);
    std::cout << "[INFO] CPU cexp run_rx execution time " << timeMicroSec.count() << "us\n";
#endif

#ifdef DEBUG_PRINTF
    cout << "[INFO] cexp_t run_rx  exiting" << endl;
#endif
};

float cexp_t::run_est(complex_t *input)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] cexp_t run_est  entering" << endl;
#endif

#ifdef CFO_EST_PRINT_TIME
    auto start = std::chrono::high_resolution_clock::now();
#endif

    int idx = 0;
    xCorr[0].real = 0.0;
    xCorr[0].imag = 0.0;
    for (int n = 0; n < nSym; n++)
    {
        for (int k = guard; k < cpSizes[n] - guard; k++)
        {
            complex_t r_cp = input[k + idx];
            complex_t r_tail = input[k + idx + nFFT];
            xCorr[0] = xCorr[0] + (r_cp.conj() * r_tail);
        }
        idx += (nFFT + cpSizes[n]);
    }
    float angle;
    if (xCorr[0].real != 0.0)
    {
        angle = (float)atan(xCorr[0].imag / xCorr[0].real);
    }
    else // avoid division by 0.0
    {
        angle = xCorr[0].imag > 0 ? PI / 2.0 : -PI / 2.0;
    }
    float newcfo = angle / (2 * PI * nFFT);
    // exponential filter, 0 <= alpha <= 1  is the forgotten factor
    cfo = (1 - alpha) * cfo + alpha * newcfo;

    // estimate STO
    idx = cpSizes[0] + nFFT;
    for (int t = 0; t < maxSto + 1; t++)
    {
        xCorr[t].real = 0.0;
        xCorr[t].imag = 0.0;
    }
    for (int n = 1; n < nSym - 1; n++)
    {
        for (int t = -maxSto / 2; t < maxSto / 2 + 1; t++)
        {
            for (int k = 0; k < cpSizes[n]; k++)
            {
                complex_t r_cp = input[k + idx + t];
                complex_t r_tail = input[k + idx + nFFT + t];
                xCorr[t + maxSto / 2] = xCorr[t + maxSto / 2] + (r_cp.conj() * r_tail);
            }
        }
        idx += (nFFT + cpSizes[n]);
    }
    // find max xCorr position
    float val = 0;
    int pos = 0;
    for (int n = 0; n < maxSto + 1; n++)
    {
        float tmp = xCorr[n].abs2();
        if (val < tmp)
        {
            val = tmp;
            pos = n;
        }
    }
    float newSto = pos - maxSto / 2;
    sto = (1 - alpha) * sto + alpha * newSto;
    if (sto > marginCp) sto = marginCp;
    if (sto < -marginCp) sto = -marginCp;

#ifdef CFO_EST_PRINT_TIME
    auto stop = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> delta = stop - start;
    std::chrono::microseconds timeMicroSec = std::chrono::duration_cast<std::chrono::microseconds>(delta);
    std::cout << "[INFO] CPU cexp run_est execution time " << timeMicroSec.count() << "us\n";
#endif
#ifdef DEBUG_PRINTF
    cout << "[INFO] cexp_t run_est  exiting" << endl;
#endif
    return sto;
};