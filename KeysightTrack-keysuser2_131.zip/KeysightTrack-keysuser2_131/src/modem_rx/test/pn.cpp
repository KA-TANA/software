#include "pn.hpp"

using namespace hostPn;
using namespace std;

pn_t::pn_t(bool *seed)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] pn_t constructor entering" << endl;
#endif

    for (int n = 0; n < 23; n++) state[n] = seed[n];

#ifdef DEBUG_PRINTF
    cout << "[INFO] pn_t constructor exiting" << endl;
#endif
}

pn_t::~pn_t(void)
{
#ifdef DEBUG_PRINTF
    cout << "[INFO] pn_t destructor entering" << endl;
    cout << "[INFO] pn_t destructor exiting" << endl;
#endif
}
void pn_t::run(int *output)
{
    for (int r = 0; r < 2; r++)
    {
        output[r] = 0;
        for (int c = 0; c < 23; c++) output[r] ^= C[r][c] & state[c];
    }

    for (int r = 0; r < 2; r++)
    {
        output[r] = 0;
        for (int c = 0; c < 23; c++) output[r] ^= C[r][c] & state[c];
    }

    int nxt[24];
    for (int r = 0; r < 23; r++)
    {
        nxt[r] = 0;
        for (int c = 0; c < 23; c++) nxt[r] ^= D[r][c] & state[c];
    }

    for (int c = 0; c < 23; c++) state[c] = nxt[c];
};
