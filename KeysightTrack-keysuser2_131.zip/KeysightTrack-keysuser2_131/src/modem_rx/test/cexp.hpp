#pragma once
#include "mtypes.hpp"

#ifdef PRINT_EXECUTION_TIMES
#define CEXP_PRINT_TIME
#define CFO_EST_PRINT_TIME
#endif

namespace hostCexp
{

#define PI 3.14159265358979323846
class cexp_t
{
public:
    float cfo = 0.0; // cfo frequency, normalized by the sampling frequency
    int slotSize;    // slot size in samples
    int nSym;        // symbols per slot
    int *cpSizes;    // array of cp lengths
    int nFFT;        // fft size
    int guard = 16;  // guard against ISI
    float alpha = 0.99;
    float sto = 0.0;
    int marginCp;
    int maxSto;
    complex_t *xCorr;
    // constructor
    cexp_t() = delete;
    cexp_t(int FFTSize, int nSymbol, int *cpSizes);

    // destructor
    virtual ~cexp_t();

    // cfo removal
    void run_rx(complex_t *input, complex_t *output);
    float run_est(complex_t *input);
};

}
