#include "map.hpp"
#include <ctime>
#include <chrono>

using namespace hostMap;

map_t::map_t(int FFTSize, int nSymbol, bool *freqMask, bool *pdchMask)
{
#ifdef DEBUG_PRINTF
    printf("[INFO] map_t constructor entering\n");
#endif

    nFFT = FFTSize;
    nSym = nSymbol;
    FreqMask = freqMask;
    TimeMask = pdchMask;

#ifdef DEBUG_PRINTF
    printf("[INFO] map_t constructor exiting\n");
#endif
}

map_t::~map_t(void)
{
#ifdef DEBUG_PRINTF
    printf("[INFO] map_t destructor entering\n");
    printf("[INFO] map_t destructor exiting\n");
#endif
}
void map_t::run_rx(complex_t *input, complex_t *output)
{
#ifdef DEBUG_PRINTF
    printf("[INFO] map_t run_rx entering\n");
#endif
#ifdef MAP_PRINT_TIME
    auto start = std::chrono::high_resolution_clock::now();
#endif


    int m = 0;
    for (int n = 0; n < nSym; n++)
        for (int k = 0; k < nFFT; k++)
        {
            if (FreqMask[k] && TimeMask[n]) output[m++] = input[n * nFFT + k];
        }

#ifdef MAP_PRINT_TIME
    auto stop = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> delta = stop - start;
    std::chrono::microseconds timeMicroSec = std::chrono::duration_cast<std::chrono::microseconds>(delta);
    std::cout << "[INFO] CPU map run_rx execution time " << timeMicroSec.count() << "us\n";
#endif
#ifdef DEBUG_PRINTF
    printf("[INFO] map_t run_rx exiting\n");
#endif
};
