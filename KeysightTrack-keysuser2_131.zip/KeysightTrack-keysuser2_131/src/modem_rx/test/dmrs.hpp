#pragma once
#include "mtypes.hpp"
#include "pn.hpp"

#ifdef PRINT_EXECUTION_TIMES
#endif

namespace hostDmrs
{

using namespace hostPn;

class dmrs_t
{
public:
    int nFFT;       // cell BW,  DFT size
    int nSym;       //
    bool *FreqMask; // channel allocation mask in frequency for data
    bool *TimeMask; // DMRS position mask
    pn_t *pn;
    complex_t qpsk[4];

    // constructors
    dmrs_t() = delete;
    dmrs_t(int FFTSize, int nSymbol, bool *freqMask, bool *dmrsMask);

    // destructor
    virtual ~dmrs_t();

    void run(complex_t *output);
};

}
