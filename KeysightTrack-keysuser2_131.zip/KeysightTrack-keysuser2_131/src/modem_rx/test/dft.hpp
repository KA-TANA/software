#pragma once
#include "mtypes.hpp"

#ifdef PRINT_EXECUTION_TIMES
#define DFT_PRINT_TIME
#endif

namespace hostDft
{

class dft_t
{
public:
    int dftSize;
    int nSymb;
    complex_t *W;

    // constructor
    dft_t() = delete;
    dft_t(int nSymbols, int size);

    // destructor
    virtual ~dft_t();

    void run_fft(complex_t *input, complex_t *output);

private:
    void fft_recursion(complex_t *input, complex_t *output, int nFFT);
};

}
