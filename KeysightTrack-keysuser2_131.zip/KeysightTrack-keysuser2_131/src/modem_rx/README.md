# Directory Structure

The following directory structure is used:

- `data`: Contains test vector files.
- `inc`: Header files for the component.
- `matlab`: Contains Matlab reference code.
- `src`: Source code for the component.
- `test`: Code for unit testing of the component.
