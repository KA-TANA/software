#include <stdio.h>
#include "scalarProduct.hpp"
#include <ctime>
#include <chrono>

#define NREP 100

//
// version 0: new beginners version run in host side
//
using namespace SP;

float SP::scalarProduct(float *x, float *y, int dim, float *us)
{
    printf("[HST] using host scalarProduct version 0\n");

    auto start = std::chrono::high_resolution_clock::now();

    float z;
    for (int n=0; n<NREP; n++)
    {
        float sum = 0.0;
        for (int n = 0; n < dim; n++)
            sum += x[n] * y[n];
        z = sum;
    }

    auto stop = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> delta = stop - start;
    std::chrono::microseconds timeMicroSec = std::chrono::duration_cast<std::chrono::microseconds>(delta);

    *us = (float)(timeMicroSec.count()/NREP);
    return z;
}
