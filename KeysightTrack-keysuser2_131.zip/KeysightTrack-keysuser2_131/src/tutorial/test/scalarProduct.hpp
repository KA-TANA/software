#pragma once

namespace SP
{
/**
 * @brief scalarProduct
 *
 * @param x pointer to first input vector
 * @param y pointer to second input vector
 * @param dim   length of input vector
 * @param ms pointer to execution time in ms
 * @return scalar product x' * y
 */
float scalarProduct(float *x, float *y, int dim, float *ms);

}
