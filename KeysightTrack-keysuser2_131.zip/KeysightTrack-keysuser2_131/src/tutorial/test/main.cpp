/*
<<<<<<< HEAD
//#include "helloWorld.cuh"
=======
#include "helloWorld.cuh"
>>>>>>> remotes/origin/keysuser4_131

int main(int argc, char **argv)
{
    int numBlocks = 1;
    int numThreads = 1;
    hw::helloWorld(numBlocks,numThreads);

}
*/
<<<<<<< HEAD
/*
#include <iostream>
#include <fstream>
//#include "cudaScalarProduct1.cuh"
//#include "cudaScalarProduct2.cuh"
#include "cudaScalarProduct3.cuh"
//#include "scalarProduct.hpp"
=======


/*
#include <iostream>
#include <fstream>
#include "scalarProduct.hpp"
//#include "cudaScalarProduct1.cuh"
//#include "cudaScalarProduct2.cuh"
//#include "cudaScalarProduct3.cuh"

>>>>>>> remotes/origin/keysuser4_131
#define DIM (1024 * 1024)
float x[DIM];
float y[DIM];
//using namespace SP;
using namespace std;
<<<<<<< HEAD
=======
using namespace SP;
>>>>>>> remotes/origin/keysuser4_131
//using namespace cudaSP1;
//using namespace cudaSP2;
using namespace cudaSP3;

int main(int argc, char **argv)
{
    // fetch vector x from file
    ifstream fid;
    fid.open(argv[1]);
    if (!fid)
    {
        cout << "[ERROR] " << argv[1] << " not found" << endl;
        exit(0);
    }
    cout << "[HST] reading file " << argv[1] << " into vector x" << endl;
    for (int row = 0; row < DIM; row++) fid >> x[row];
    fid.close();

    // fetch vector y from file
    fid.open(argv[2]);
    if (!fid)
    {
        cout << "[ERROR] " << argv[2] << " not found" << endl;
        exit(0);
    }
    cout << "[HST] reading file " << argv[2] << " into vector y" << endl;
    for (int row = 0; row < DIM; row++) fid >> y[row];
    fid.close();

    //
    // computation of scalar vector product
    //
    cout << "[HST] computation of scalar product x'y" << endl;
    float us;
    float z = scalarProduct(x, y, DIM, &us);
    printf("[HST] x'y =  %7.1f\n", z);
    printf("[HST] x'y execution time %.1f us\n", us);

}

*/

<<<<<<< HEAD




#include <iostream>

#include <fstream>

#include "homework1.cuh"



#define DIM (1024 * 1024)

float x[DIM];

float y[DIM];

float z_ref[DIM];

float z[DIM];



using namespace std;

using namespace cudaVP;



int main(int argc, char **argv)

{

    // fetch vector x from file

    ifstream fid;

    fid.open(argv[1]);

    if (!fid)

    {

        cout << "\n\n" << "[ERROR] " << argv[1] << " not found" << endl;

        exit(0);

    }

    cout << "[HST] reading file " << argv[1] << " into vector x" << endl;

    for (int row = 0; row < DIM; row++) fid >> x[row];

    fid.close();



    // fetch vector y from file

    fid.open(argv[2]);

    if (!fid)

    {

        cout << "[ERROR] " << argv[2] << " not found" << endl;

        exit(0);

    }

    cout << "[HST] reading file " << argv[2] << " into vector y" << endl;

    for (int row = 0; row < DIM; row++) fid >> y[row];

    fid.close();



    // fetch vector z_ref from file

    fid.open(argv[3]);

    if (!fid)

    {

        cout << "[ERROR] " << argv[3] << " not found" << endl;

        exit(0);

    }

    cout << "[HST] reading file " << argv[3] << " into vector z_ref" << endl << endl;

    for (int row = 0; row < DIM; row++) fid >> z_ref[row];

    fid.close();



    //

    // computation of vector projection

    //

    float us;

    vectorProjection(x, y, z, DIM, &us);



    printf("[HST] (x'y)/(y'y)y execution time %.1f us\n", us);



    // print some results

    printf("[HST] [z_ref, z](0:%d) =  ", DIM-1);

    for (int n =0; n<4; n++) printf("(%8.2e,%8.2e),", z_ref[n],z[n]);

    printf("...");

    for (int n =DIM-4; n<DIM; n++) printf("(%8.2e,%8.2e),", z_ref[n],z[n]);

    printf("\n");



    // compute error (z-z_ref)'(z-z_ref)

    float error = 0.0;

    for (int n = 0; n<DIM; n++) error += (z[n]-z_ref[n]) * (z[n]-z_ref[n]);

    printf("[HST] (z-z_ref)'(z-z_ref) =  %7.1e\n", error);



=======
#include <iostream>
#include <fstream>
#include "cudaVectorProjection.cuh"

// Number of elements to be read/calculated
#define DIM (1024 * 1024)
// Float arrays that will store X, Y, Z_reference and Z_calculated
float x[DIM];
float y[DIM];
float z_ref[DIM];
float z[DIM];

using namespace std;
using namespace cudaVP;

int main(int argc, char **argv)
{
    // fetch vector x from file
    // file name for x in first program parameter
    // argv[0] contains the executable name, so we access argv[1]
    ifstream fid;
    fid.open(argv[1]);
    if (!fid)	// File not found!
    {
        cout << "\n\n" << "[ERROR] " << argv[1] << " not found" << endl;
        exit(0);
    }
    cout << "[HST] reading file " << argv[1] << " into vector x" << endl;
    for (int row = 0; row < DIM; row++) fid >> x[row];	// every element is in its own row
    fid.close();	// close the file after reading

    // fetch vector y from file
    // file name for y in second program parameter
    fid.open(argv[2]);
    if (!fid)
    {
        cout << "[ERROR] " << argv[2] << " not found" << endl;
        exit(0);
    }
    cout << "[HST] reading file " << argv[2] << " into vector y" << endl;
    for (int row = 0; row < DIM; row++) fid >> y[row];
    fid.close();

    // fetch vector z_ref from file
    // this will be used to measure the error in our calculations
    // file name for z_ref in third program parameter
    fid.open(argv[3]);
    if (!fid)
    {
        cout << "[ERROR] " << argv[3] << " not found" << endl;
        exit(0);
    }
    cout << "[HST] reading file " << argv[3] << " into vector z_ref" << endl << endl;
    for (int row = 0; row < DIM; row++) fid >> z_ref[row];
    fid.close();

    //
    // computation of vector projection
    // (through the use of a CUDA kernel)
    //
    float us;	// microseconds
    vectorProjection(x, y, z, DIM, &us);

    // execution time in microsends
    printf("[HST] (x'y)/(y'y)y execution time %.1f us\n", us);

    // print some results
    // showing a preview of the reference and our results
    printf("[HST] [z_ref, z](0:%d) =  ", DIM-1);
    for (int n =0; n<4; n++) printf("(%8.2e,%8.2e),", z_ref[n],z[n]);
    printf("...");
    for (int n =DIM-4; n<DIM; n++) printf("(%8.2e,%8.2e),", z_ref[n],z[n]);
    printf("\n");

    // compute error (z-z_ref)'(z-z_ref)
    // squared error
    float error = 0.0;
    for (int n = 0; n<DIM; n++) error += (z[n]-z_ref[n]) * (z[n]-z_ref[n]);
    printf("[HST] (z-z_ref)'(z-z_ref) =  %7.1e\n", error);

>>>>>>> remotes/origin/keysuser4_131
}
